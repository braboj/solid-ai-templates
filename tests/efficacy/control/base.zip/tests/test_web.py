import csv
import io
import json

from .conftest import csrf_token


# -- dashboard & seed fixture -------------------------------------------

def test_dashboard(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert b"tariff" in resp.data


def test_seed_fixture_present(client):
    resp = client.get("/products")
    text = resp.get_data(as_text=True)
    for sku in ("WID-1", "GAD-2", "BOK-3", "SRV-4", "SEE-5"):
        assert sku in text

    resp = client.get("/jurisdictions")
    text = resp.get_data(as_text=True)
    assert "DE" in text and "IE" in text

    resp = client.get("/rules")
    text = resp.get_data(as_text=True)
    for rule_id in ("r-tier-wid", "r-bulk-see", "r-pct-bok", "r-pct-all", "c-welcome", "c-tenoff"):
        assert rule_id in text


# -- CSRF -----------------------------------------------------------------

def test_post_without_csrf_is_refused(client):
    resp = client.post("/products", data={"sku": "X-1", "name": "X", "unit_price": "1.00", "tax_category": "standard"})
    assert resp.status_code in (400, 403)


def test_post_with_wrong_csrf_is_refused(client):
    resp = client.post(
        "/products",
        data={"sku": "X-1", "name": "X", "unit_price": "1.00", "tax_category": "standard", "csrf_token": "bogus"},
    )
    assert resp.status_code in (400, 403)


# -- products ---------------------------------------------------------------

def test_create_and_delete_product(client):
    token = csrf_token(client, "/products")
    resp = client.post(
        "/products",
        data={"sku": "NEW-1", "name": "New thing", "unit_price": "5.00", "tax_category": "standard", "csrf_token": token},
    )
    assert resp.status_code == 303

    resp = client.get("/products")
    assert "NEW-1" in resp.get_data(as_text=True)

    token = csrf_token(client, "/products")
    resp = client.post("/products/NEW-1/delete", data={"csrf_token": token})
    assert resp.status_code == 303
    resp = client.get("/products")
    assert "NEW-1" not in resp.get_data(as_text=True)


def test_create_product_validation_error_is_200(client):
    token = csrf_token(client, "/products")
    resp = client.post(
        "/products",
        data={"sku": "", "name": "New thing", "unit_price": "5.00", "tax_category": "standard", "csrf_token": token},
    )
    assert resp.status_code == 200
    assert "sku" in resp.get_data(as_text=True)


def test_create_duplicate_sku_is_validation_error(client):
    token = csrf_token(client, "/products")
    resp = client.post(
        "/products",
        data={"sku": "WID-1", "name": "Dup", "unit_price": "1.00", "tax_category": "standard", "csrf_token": token},
    )
    assert resp.status_code == 200
    assert "already exists" in resp.get_data(as_text=True)


def test_delete_unknown_product_is_404(client):
    token = csrf_token(client, "/products")
    resp = client.post("/products/NOPE/delete", data={"csrf_token": token})
    assert resp.status_code == 404


# -- rules ------------------------------------------------------------------

def test_create_percentage_rule(client):
    token = csrf_token(client, "/rules")
    resp = client.post(
        "/rules",
        data={"rule_id": "r-new", "kind": "percentage", "sku": "", "percent": "15", "csrf_token": token},
    )
    assert resp.status_code == 303
    resp = client.get("/rules")
    assert "r-new" in resp.get_data(as_text=True)


def test_create_tiered_rule(client):
    token = csrf_token(client, "/rules")
    resp = client.post(
        "/rules",
        data={
            "rule_id": "r-tier-new", "kind": "tiered", "sku": "GAD-2",
            "tiers": "1:20.00,5:18.00", "csrf_token": token,
        },
    )
    assert resp.status_code == 303


def test_create_coupon_rule_needs_exactly_one_of_percent_amount(client):
    token = csrf_token(client, "/rules")
    resp = client.post(
        "/rules",
        data={"rule_id": "r-bad-coupon", "kind": "coupon", "code": "BAD", "csrf_token": token},
    )
    assert resp.status_code == 200
    assert "r-bad-coupon" not in resp.get_data(as_text=True) or "amount" in resp.get_data(as_text=True).lower()


def test_create_duplicate_rule_id_is_validation_error(client):
    token = csrf_token(client, "/rules")
    resp = client.post(
        "/rules",
        data={"rule_id": "r-pct-all", "kind": "percentage", "sku": "", "percent": "1", "csrf_token": token},
    )
    assert resp.status_code == 200
    assert "already exists" in resp.get_data(as_text=True)


def test_delete_unknown_rule_is_404(client):
    token = csrf_token(client, "/rules")
    resp = client.post("/rules/nope/delete", data={"csrf_token": token})
    assert resp.status_code == 404


# -- jurisdictions ------------------------------------------------------------

def test_create_and_delete_jurisdiction(client):
    token = csrf_token(client, "/jurisdictions")
    resp = client.post(
        "/jurisdictions",
        data={"code": "FR", "name": "France", "default_rate": "0.20", "rates": "standard=0.20,reduced=0.10", "csrf_token": token},
    )
    assert resp.status_code == 303
    resp = client.get("/jurisdictions")
    assert "FR" in resp.get_data(as_text=True)

    token = csrf_token(client, "/jurisdictions")
    resp = client.post("/jurisdictions/FR/delete", data={"csrf_token": token})
    assert resp.status_code == 303


def test_delete_unknown_jurisdiction_is_404(client):
    token = csrf_token(client, "/jurisdictions")
    resp = client.post("/jurisdictions/ZZ/delete", data={"csrf_token": token})
    assert resp.status_code == 404


# -- invoice builder: preview -----------------------------------------------

def _worked_example_form(token):
    return {
        "jurisdiction": "DE",
        "currency": "EUR",
        "coupon_codes": "WELCOME",
        "sku": ["WID-1", "SEE-5", "BOK-3", "SRV-4"],
        "quantity": ["12", "7", "2", "1"],
        "csrf_token": token,
    }


def test_preview_worked_example_full_page(client):
    token = csrf_token(client, "/invoices/new")
    resp = client.post("/invoices/preview", data=_worked_example_form(token))
    assert resp.status_code == 200
    text = resp.get_data(as_text=True)
    assert "227.07" in text
    assert "<html" in text.lower()


def test_preview_worked_example_htmx_fragment(client):
    token = csrf_token(client, "/invoices/new")
    resp = client.post(
        "/invoices/preview", data=_worked_example_form(token), headers={"HX-Request": "true"}
    )
    assert resp.status_code == 200
    text = resp.get_data(as_text=True)
    assert "227.07" in text
    assert "<html" not in text.lower()


def test_preview_unknown_sku_is_400(client):
    token = csrf_token(client, "/invoices/new")
    data = {
        "jurisdiction": "DE", "currency": "EUR", "coupon_codes": "",
        "sku": ["NOPE"], "quantity": ["1"], "csrf_token": token,
    }
    resp = client.post("/invoices/preview", data=data)
    assert resp.status_code == 400


def test_preview_unknown_jurisdiction_is_400(client):
    token = csrf_token(client, "/invoices/new")
    data = {
        "jurisdiction": "ZZ", "currency": "EUR", "coupon_codes": "",
        "sku": ["WID-1"], "quantity": ["1"], "csrf_token": token,
    }
    resp = client.post("/invoices/preview", data=data)
    assert resp.status_code == 400


def test_preview_quantity_below_one_is_400(client):
    token = csrf_token(client, "/invoices/new")
    data = {
        "jurisdiction": "DE", "currency": "EUR", "coupon_codes": "",
        "sku": ["WID-1"], "quantity": ["0"], "csrf_token": token,
    }
    resp = client.post("/invoices/preview", data=data)
    assert resp.status_code == 400


def test_preview_no_lines_is_200_with_message(client):
    token = csrf_token(client, "/invoices/new")
    data = {"jurisdiction": "DE", "currency": "EUR", "coupon_codes": "", "sku": [""], "quantity": [""], "csrf_token": token}
    resp = client.post("/invoices/preview", data=data)
    assert resp.status_code == 200


def test_preview_half_filled_pair_is_200_validation_error(client):
    token = csrf_token(client, "/invoices/new")
    data = {
        "jurisdiction": "DE", "currency": "EUR", "coupon_codes": "",
        "sku": ["WID-1"], "quantity": [""], "csrf_token": token,
    }
    resp = client.post("/invoices/preview", data=data)
    assert resp.status_code == 200
    assert "quantity" in resp.get_data(as_text=True).lower()


def test_preview_unknown_coupon_code_is_200_validation_error(client):
    token = csrf_token(client, "/invoices/new")
    data = {
        "jurisdiction": "DE", "currency": "EUR", "coupon_codes": "NOPE",
        "sku": ["WID-1"], "quantity": ["1"], "csrf_token": token,
    }
    resp = client.post("/invoices/preview", data=data)
    assert resp.status_code == 200


def test_preview_currency_defaults_to_eur(client):
    token = csrf_token(client, "/invoices/new")
    data = {
        "jurisdiction": "DE", "coupon_codes": "",
        "sku": ["WID-1"], "quantity": ["1"], "csrf_token": token,
    }
    resp = client.post("/invoices/preview", data=data, headers={"HX-Request": "true"})
    assert resp.status_code == 200


# -- invoice builder: save + view + exports ----------------------------------

def test_save_no_lines_is_400(client):
    token = csrf_token(client, "/invoices/new")
    data = {"jurisdiction": "DE", "currency": "EUR", "coupon_codes": "", "sku": [""], "quantity": [""], "csrf_token": token}
    resp = client.post("/invoices", data=data)
    assert resp.status_code == 400


def test_save_and_view_worked_example(client):
    token = csrf_token(client, "/invoices/new")
    resp = client.post("/invoices", data=_worked_example_form(token))
    assert resp.status_code == 303
    location = resp.headers["Location"]

    resp = client.get(location)
    assert resp.status_code == 200
    text = resp.get_data(as_text=True)
    assert "227.07" in text
    assert "108.00" in text  # WID-1 net


def test_view_unknown_invoice_is_404(client):
    resp = client.get("/invoices/999999")
    assert resp.status_code == 404
    resp = client.get("/invoices/999999/export.json")
    assert resp.status_code == 404
    resp = client.get("/invoices/999999/export.csv")
    assert resp.status_code == 404
    resp = client.get("/invoices/999999/print")
    assert resp.status_code == 404


def test_export_json_matches_spec_shape_and_worked_example(client):
    token = csrf_token(client, "/invoices/new")
    resp = client.post("/invoices", data=_worked_example_form(token))
    invoice_id = int(resp.headers["Location"].rstrip("/").rsplit("/", 1)[-1])

    resp = client.get(f"/invoices/{invoice_id}/export.json")
    assert resp.status_code == 200
    assert resp.content_type == "application/json"

    payload = json.loads(resp.get_data(as_text=True))
    assert list(payload.keys()) == [
        "invoice_id", "currency", "jurisdiction", "lines",
        "subtotal", "discount_total", "taxable_total", "tax_total", "total", "applied",
    ]
    assert payload["invoice_id"] == invoice_id
    assert payload["currency"] == "EUR"
    assert payload["jurisdiction"] == "DE"
    assert payload["subtotal"] == "228.35"
    assert payload["discount_total"] == "33.11"
    assert payload["taxable_total"] == "195.24"
    assert payload["tax_total"] == "31.83"
    assert payload["total"] == "227.07"
    assert payload["applied"] == ["r-pct-all", "c-welcome"]

    wid_line = payload["lines"][0]
    assert list(wid_line.keys()) == [
        "sku", "name", "quantity", "unit_price", "gross", "line_discount",
        "net", "invoice_discount", "taxable", "tax", "total", "applied",
    ]
    assert wid_line["sku"] == "WID-1"
    assert wid_line["gross"] == "120.00"
    assert wid_line["net"] == "108.00"
    assert wid_line["invoice_discount"] == "15.66"
    assert wid_line["total"] == "109.88"
    assert wid_line["applied"] == ["r-tier-wid"]

    # byte-stable
    resp2 = client.get(f"/invoices/{invoice_id}/export.json")
    assert resp2.get_data() == resp.get_data()


def test_export_csv_shape_and_totals_row(client):
    token = csrf_token(client, "/invoices/new")
    resp = client.post("/invoices", data=_worked_example_form(token))
    invoice_id = int(resp.headers["Location"].rstrip("/").rsplit("/", 1)[-1])

    resp = client.get(f"/invoices/{invoice_id}/export.csv")
    assert resp.status_code == 200
    assert resp.content_type == "text/csv; charset=utf-8"
    body = resp.get_data(as_text=True)
    assert "\r\n" not in body
    assert not body.startswith("﻿")

    rows = list(csv.reader(io.StringIO(body)))
    assert rows[0] == [
        "sku", "name", "quantity", "unit_price", "gross", "line_discount",
        "net", "invoice_discount", "taxable", "tax", "total",
    ]
    assert len(rows) == 1 + 4 + 1  # header + 4 lines + total
    total_row = rows[-1]
    assert total_row[0] == "TOTAL"
    assert total_row[1] == ""
    assert total_row[2] == ""
    assert total_row[3] == ""
    assert total_row[4] == "250.25"  # sum of gross
    assert total_row[5] == "21.90"  # sum of line_discount
    assert total_row[6] == "228.35"  # subtotal
    assert total_row[7] == "33.11"  # discount_total
    assert total_row[8] == "195.24"  # taxable_total
    assert total_row[9] == "31.83"  # tax_total
    assert total_row[10] == "227.07"  # total

    # byte-stable
    resp2 = client.get(f"/invoices/{invoice_id}/export.csv")
    assert resp2.get_data() == resp.get_data()


def test_print_page(client):
    token = csrf_token(client, "/invoices/new")
    resp = client.post("/invoices", data=_worked_example_form(token))
    invoice_id = int(resp.headers["Location"].rstrip("/").rsplit("/", 1)[-1])

    resp = client.get(f"/invoices/{invoice_id}/print")
    assert resp.status_code == 200
    assert "227.07" in resp.get_data(as_text=True)
