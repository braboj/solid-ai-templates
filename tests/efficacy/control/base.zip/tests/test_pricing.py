"""Tests for the pure pricing engine (tariff.pricing) and domain objects."""

from decimal import Decimal

import pytest

from tariff import (
    BulkRule,
    Catalog,
    CouponRule,
    Invoice,
    InvoiceLine,
    Jurisdiction,
    PercentageRule,
    Product,
    TariffError,
    TieredRule,
    price,
)


def make_de():
    return Jurisdiction(
        "DE",
        "Germany",
        {"standard": Decimal("0.19"), "reduced": Decimal("0.07"), "zero": Decimal("0.00")},
        Decimal("0.19"),
    )


def make_products():
    return {
        "WID-1": Product("WID-1", "Widget", Decimal("10.00"), "standard"),
        "GAD-2": Product("GAD-2", "Gadget", Decimal("24.50"), "standard"),
        "BOK-3": Product("BOK-3", "Handbook", Decimal("12.00"), "reduced"),
        "SRV-4": Product("SRV-4", "Support hour", Decimal("80.00"), "standard"),
        "SEE-5": Product("SEE-5", "Seed pack", Decimal("3.75"), "zero"),
    }


def make_rules():
    return [
        TieredRule("r-tier-wid", "WID-1", [(1, Decimal("10.00")), (10, Decimal("9.00")), (50, Decimal("8.00"))]),
        BulkRule("r-bulk-see", "SEE-5", 3, 2),
        PercentageRule("r-pct-bok", Decimal("10"), "BOK-3"),
        PercentageRule("r-pct-all", Decimal("5")),
        CouponRule("c-welcome", "WELCOME", percent=Decimal("10")),
        CouponRule("c-tenoff", "TENOFF", amount=Decimal("10.00")),
    ]


def test_worked_example():
    products = make_products()
    de = make_de()
    rules = make_rules()

    invoice = Invoice(
        "EUR",
        [
            InvoiceLine(products["WID-1"], 12),
            InvoiceLine(products["SEE-5"], 7),
            InvoiceLine(products["BOK-3"], 2),
            InvoiceLine(products["SRV-4"], 1),
        ],
        coupon_codes=("WELCOME",),
    )

    priced = price(invoice, rules, de)

    assert priced.subtotal == Decimal("228.35")
    assert priced.discount_total == Decimal("33.11")
    assert priced.taxable_total == Decimal("195.24")
    assert priced.tax_total == Decimal("31.83")
    assert priced.total == Decimal("227.07")
    assert priced.applied == ["r-pct-all", "c-welcome"]

    wid, see, bok, srv = priced.lines

    assert (wid.gross, wid.line_discount, wid.net, wid.invoice_discount, wid.taxable, wid.tax, wid.total) == (
        Decimal("120.00"), Decimal("12.00"), Decimal("108.00"), Decimal("15.66"),
        Decimal("92.34"), Decimal("17.54"), Decimal("109.88"),
    )
    assert wid.applied == ["r-tier-wid"]

    assert (see.gross, see.line_discount, see.net, see.invoice_discount, see.taxable, see.tax, see.total) == (
        Decimal("26.25"), Decimal("7.50"), Decimal("18.75"), Decimal("2.72"),
        Decimal("16.03"), Decimal("0.00"), Decimal("16.03"),
    )
    assert see.applied == ["r-bulk-see"]

    assert (bok.gross, bok.line_discount, bok.net, bok.invoice_discount, bok.taxable, bok.tax, bok.total) == (
        Decimal("24.00"), Decimal("2.40"), Decimal("21.60"), Decimal("3.13"),
        Decimal("18.47"), Decimal("1.29"), Decimal("19.76"),
    )
    assert bok.applied == ["r-pct-bok"]

    assert (srv.gross, srv.line_discount, srv.net, srv.invoice_discount, srv.taxable, srv.tax, srv.total) == (
        Decimal("80.00"), Decimal("0.00"), Decimal("80.00"), Decimal("11.60"),
        Decimal("68.40"), Decimal("13.00"), Decimal("81.40"),
    )
    assert srv.applied == []


def test_no_lines_raises():
    de = make_de()
    with pytest.raises(TariffError):
        price(Invoice("EUR", []), [], de)


def test_quantity_below_one_raises_at_price_time():
    products = make_products()
    de = make_de()
    line = InvoiceLine.__new__(InvoiceLine)
    line.product = products["WID-1"]
    line.quantity = 0
    invoice = Invoice.__new__(Invoice)
    invoice.currency = "EUR"
    invoice.lines = [line]
    invoice.coupon_codes = ()
    with pytest.raises(TariffError):
        price(invoice, [], de)


def test_invoice_line_refuses_bad_quantity_on_construction():
    products = make_products()
    with pytest.raises(TariffError):
        InvoiceLine(products["WID-1"], 0)


def test_duplicate_rule_id_raises():
    products = make_products()
    de = make_de()
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)])
    rules = [
        PercentageRule("dup", Decimal("5")),
        BulkRule("dup", "WID-1", 3, 2),
    ]
    with pytest.raises(TariffError):
        price(invoice, rules, de)


def test_unknown_coupon_code_raises():
    products = make_products()
    de = make_de()
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)], coupon_codes=("NOPE",))
    with pytest.raises(TariffError):
        price(invoice, make_rules(), de)


def test_coupon_code_matched_after_stripping_whitespace():
    products = make_products()
    de = make_de()
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)], coupon_codes=("  WELCOME  ",))
    priced = price(invoice, make_rules(), de)
    assert "c-welcome" in priced.applied


def test_zero_subtotal_allocates_zero():
    zero_product = Product("FREE-1", "Free thing", Decimal("0.00"), "standard")
    de = make_de()
    invoice = Invoice("EUR", [InvoiceLine(zero_product, 5)])
    priced = price(invoice, [], de)
    assert priced.lines[0].invoice_discount == Decimal("0.00")
    assert priced.subtotal == Decimal("0.00")


def test_default_rate_used_for_unknown_category():
    de = make_de()
    product = Product("X-1", "Unknown category", Decimal("100.00"), "luxury")
    invoice = Invoice("EUR", [InvoiceLine(product, 1)])
    priced = price(invoice, [], de)
    assert priced.lines[0].tax == Decimal("19.00")


# -- rule validation --------------------------------------------------------

def test_percentage_rule_bounds():
    with pytest.raises(TariffError):
        PercentageRule("r", Decimal("0"))
    with pytest.raises(TariffError):
        PercentageRule("r", Decimal("100.01"))
    PercentageRule("r", Decimal("100"))  # ok


def test_bulk_rule_bounds():
    with pytest.raises(TariffError):
        BulkRule("r", "SKU", 3, 3)  # buy must be > pay
    with pytest.raises(TariffError):
        BulkRule("r", "SKU", 3, 0)  # pay must be >= 1
    BulkRule("r", "SKU", 3, 2)  # ok


def test_tiered_rule_validation():
    with pytest.raises(TariffError):
        TieredRule("r", "SKU", [])
    with pytest.raises(TariffError):
        TieredRule("r", "SKU", [(0, Decimal("1"))])
    with pytest.raises(TariffError):
        TieredRule("r", "SKU", [(1, Decimal("-1"))])
    with pytest.raises(TariffError):
        TieredRule("r", "SKU", [(5, Decimal("1")), (5, Decimal("2"))])
    with pytest.raises(TariffError):
        TieredRule("r", "SKU", [(5, Decimal("1")), (2, Decimal("2"))])


def test_coupon_rule_validation():
    with pytest.raises(TariffError):
        CouponRule("r", "")
    with pytest.raises(TariffError):
        CouponRule("r", "CODE")  # neither percent nor amount
    with pytest.raises(TariffError):
        CouponRule("r", "CODE", percent=Decimal("10"), amount=Decimal("1"))  # both
    with pytest.raises(TariffError):
        CouponRule("r", "CODE", amount=Decimal("0"))


def test_catalog_get_unknown_sku_raises():
    catalog = Catalog()
    catalog.add(Product("A", "a", Decimal("1"), "s"))
    assert catalog.get("A").name == "a"
    with pytest.raises(TariffError):
        catalog.get("B")
    assert len(catalog) == 1
    assert list(catalog) == [catalog.get("A")]


def test_tiered_rule_quantity_below_first_tier_unchanged():
    de = make_de()
    product = Product("T-1", "Tiered below", Decimal("5.00"), "standard")
    rule = TieredRule("r", "T-1", [(10, Decimal("4.00"))])
    invoice = Invoice("EUR", [InvoiceLine(product, 3)])
    priced = price(invoice, [rule], de)
    line = priced.lines[0]
    assert line.applied == ["r"]
    assert line.net == Decimal("15.00")  # unchanged: gross = 5*3


def test_best_of_several_rules_same_kind_selected_by_lowest_amount():
    de = make_de()
    product = Product("P-1", "Product", Decimal("100.00"), "standard")
    cheap = PercentageRule("r-big", Decimal("50"), "P-1")
    expensive = PercentageRule("r-small", Decimal("10"), "P-1")
    invoice = Invoice("EUR", [InvoiceLine(product, 1)])
    priced = price(invoice, [cheap, expensive], de)
    assert priced.lines[0].applied == ["r-big"]


def test_tie_broken_by_rule_id_ascending():
    de = make_de()
    product = Product("P-1", "Product", Decimal("100.00"), "standard")
    rule_b = PercentageRule("b-rule", Decimal("10"), "P-1")
    rule_a = PercentageRule("a-rule", Decimal("10"), "P-1")
    invoice = Invoice("EUR", [InvoiceLine(product, 1)])
    priced = price(invoice, [rule_b, rule_a], de)
    assert priced.lines[0].applied == ["a-rule"]
