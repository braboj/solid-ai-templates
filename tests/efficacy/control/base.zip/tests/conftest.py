import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import tariff

CSRF_RE = re.compile(r'name="csrf_token" value="([^"]+)"')


@pytest.fixture()
def app(tmp_path):
    db_path = tmp_path / "tariff.db"
    application = tariff.create_app(str(db_path))
    application.config.update(TESTING=True)
    return application


@pytest.fixture()
def client(app):
    return app.test_client()


def csrf_token(client, path="/products"):
    resp = client.get(path)
    match = CSRF_RE.search(resp.get_data(as_text=True))
    assert match, f"no csrf token found on {path}"
    return match.group(1)
