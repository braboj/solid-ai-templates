"""Parsing and formatting for the compound form fields described in
SPEC.md section 6.1: tiers, rates and coupon_codes."""

from decimal import Decimal, InvalidOperation


class FieldError(Exception):
    """Raised when a compound field cannot be parsed. Carries no field name;
    callers attach the field name themselves."""


def parse_decimal(raw: str) -> Decimal:
    try:
        return Decimal(raw.strip())
    except (InvalidOperation, AttributeError):
        raise FieldError(f"{raw!r} is not a valid number") from None


def parse_tiers(raw: str):
    """'1:10.00,10:9.00,50:8.00' -> ((1, Decimal('10.00')), ...)"""
    raw = (raw or "").strip()
    if not raw:
        raise FieldError("tiers must not be empty")
    tiers = []
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if ":" not in chunk:
            raise FieldError(f"{chunk!r} is not a min_quantity:unit_price pair")
        qty_raw, price_raw = chunk.split(":", 1)
        try:
            qty = int(qty_raw.strip())
        except ValueError:
            raise FieldError(f"{qty_raw!r} is not a whole number") from None
        tiers.append((qty, parse_decimal(price_raw)))
    if not tiers:
        raise FieldError("tiers must not be empty")
    return tuple(tiers)


def format_tiers(tiers) -> str:
    return ",".join(f"{qty}:{price:.2f}" for qty, price in tiers)


def parse_rates(raw: str) -> dict:
    """'standard=0.19,reduced=0.07' -> {'standard': Decimal('0.19'), ...}"""
    raw = (raw or "").strip()
    rates = {}
    if not raw:
        return rates
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "=" not in chunk:
            raise FieldError(f"{chunk!r} is not a category=rate pair")
        category, rate_raw = chunk.split("=", 1)
        category = category.strip()
        if not category:
            raise FieldError("a rate's category must not be empty")
        rates[category] = parse_decimal(rate_raw)
    return rates


def format_rates(rates: dict) -> str:
    return ",".join(f"{category}={rate}" for category, rate in rates.items())


def parse_coupon_codes(raw: str):
    raw = (raw or "").strip()
    if not raw:
        return []
    return [code.strip() for code in raw.split(",") if code.strip()]


def format_coupon_codes(codes) -> str:
    return ",".join(codes)
