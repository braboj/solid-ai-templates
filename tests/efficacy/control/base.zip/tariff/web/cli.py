"""Command-line entry points: ``tariff-seed`` and ``tariff-serve``."""

import argparse

from . import db as db_module


def seed_main(argv=None) -> None:
    parser = argparse.ArgumentParser(
        prog="tariff-seed",
        description="Reset a tariff database to the seed fixture (SPEC.md section 8).",
    )
    parser.add_argument("database", help="path to the sqlite database file")
    args = parser.parse_args(argv)
    db_module.seed_db(args.database)
    print(f"Seeded {args.database}")


def serve_main(argv=None) -> None:
    parser = argparse.ArgumentParser(
        prog="tariff-serve",
        description="Run the tariff web application.",
    )
    parser.add_argument("database", help="path to the sqlite database file")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args(argv)

    from . import create_app

    app = create_app(args.database)
    app.run(host=args.host, port=args.port, debug=args.debug)
