"""The tariff web application factory.

Importing this module requires Flask; ``tariff`` only imports it lazily
(see ``tariff.__getattr__``), so ``import tariff`` alone never requires
Flask or touches the database.
"""

import os

from flask import Flask

from . import db as db_module
from .views.invoices import bp as invoices_bp
from .views.jurisdictions import bp as jurisdictions_bp
from .views.products import bp as products_bp
from .views.rules import bp as rules_bp
from .csrf import init_csrf


def create_app(db_path: str) -> Flask:
    app = Flask(__name__)
    app.config["DATABASE"] = os.fspath(db_path)
    app.config["SECRET_KEY"] = os.environ.get("TARIFF_SECRET_KEY", os.urandom(32))

    db_module.init_db(app.config["DATABASE"])

    init_csrf(app)

    app.register_blueprint(products_bp)
    app.register_blueprint(rules_bp)
    app.register_blueprint(jurisdictions_bp)
    app.register_blueprint(invoices_bp)

    @app.route("/")
    def dashboard():
        from flask import render_template

        return render_template("dashboard.html")

    @app.teardown_appcontext
    def close_db(exception=None):
        db_module.close_connection()

    return app
