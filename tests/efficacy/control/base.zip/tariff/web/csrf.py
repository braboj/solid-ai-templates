"""Minimal CSRF protection: a per-session token embedded as a hidden field
in every form and checked on every POST."""

import secrets

from flask import Flask, abort, request, session


def get_csrf_token() -> str:
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_hex(32)
        session["csrf_token"] = token
    return token


def init_csrf(app: Flask) -> None:
    app.jinja_env.globals["csrf_token"] = get_csrf_token

    @app.before_request
    def check_csrf():
        if request.method != "POST":
            return None
        submitted = request.form.get("csrf_token", "")
        expected = session.get("csrf_token", "")
        if not submitted or not expected or not secrets.compare_digest(submitted, expected):
            abort(400, description="missing or invalid CSRF token")
        return None
