"""SQLite persistence: schema, seed fixture, and CRUD helpers.

The application owns the schema and creates it on first run. The database
stores every monetary value as text formatted to two decimal places, so
reads never lose precision and exports are byte-stable.
"""

import sqlite3
from decimal import ROUND_HALF_EVEN, Decimal

from flask import current_app, g

from ..models import Jurisdiction, Product
from ..rules import BulkRule, CouponRule, PercentageRule, TieredRule
from .formatting import format_coupon_codes, format_tiers, parse_tiers

SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
    sku TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    unit_price TEXT NOT NULL,
    tax_category TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS jurisdictions (
    code TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    default_rate TEXT NOT NULL,
    rates TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rules (
    rule_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    sku TEXT,
    percent TEXT,
    buy INTEGER,
    pay INTEGER,
    tiers TEXT,
    code TEXT,
    amount TEXT
);

CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    currency TEXT NOT NULL,
    jurisdiction_code TEXT NOT NULL,
    jurisdiction_name TEXT NOT NULL,
    coupon_codes TEXT NOT NULL,
    applied TEXT NOT NULL,
    subtotal TEXT NOT NULL,
    discount_total TEXT NOT NULL,
    taxable_total TEXT NOT NULL,
    tax_total TEXT NOT NULL,
    total TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS invoice_lines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL REFERENCES invoices(id),
    position INTEGER NOT NULL,
    sku TEXT NOT NULL,
    name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price TEXT NOT NULL,
    gross TEXT NOT NULL,
    line_discount TEXT NOT NULL,
    net TEXT NOT NULL,
    invoice_discount TEXT NOT NULL,
    taxable TEXT NOT NULL,
    tax TEXT NOT NULL,
    total TEXT NOT NULL,
    applied TEXT NOT NULL
);
"""

SEED_PRODUCTS = [
    ("WID-1", "Widget", "10.00", "standard"),
    ("GAD-2", "Gadget", "24.50", "standard"),
    ("BOK-3", "Handbook", "12.00", "reduced"),
    ("SRV-4", "Support hour", "80.00", "standard"),
    ("SEE-5", "Seed pack", "3.75", "zero"),
]

SEED_JURISDICTIONS = [
    ("DE", "Germany", "0.19", "standard=0.19,reduced=0.07,zero=0.00"),
    ("IE", "Ireland", "0.23", "standard=0.23,reduced=0.135,zero=0.00"),
]

# rule_id, kind, sku, percent, buy, pay, tiers, code, amount
SEED_RULES = [
    ("r-tier-wid", "tiered", "WID-1", None, None, None, "1:10.00,10:9.00,50:8.00", None, None),
    ("r-bulk-see", "bulk", "SEE-5", None, 3, 2, None, None, None),
    ("r-pct-bok", "percentage", "BOK-3", "10", None, None, None, None, None),
    ("r-pct-all", "percentage", None, "5", None, None, None, None, None),
    ("c-welcome", "coupon", None, "10", None, None, None, "WELCOME", None),
    ("c-tenoff", "coupon", None, None, None, None, None, "TENOFF", "10.00"),
]


def _money(value: Decimal) -> str:
    return format(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN), "f")


def _connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(path: str) -> None:
    conn = _connect(path)
    try:
        conn.executescript(SCHEMA)
        conn.commit()
        count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if count == 0:
            _seed(conn)
    finally:
        conn.close()


def seed_db(path: str) -> None:
    """Reset products, jurisdictions and rules back to the section 8 fixture."""
    conn = _connect(path)
    try:
        conn.executescript(SCHEMA)
        _seed(conn)
    finally:
        conn.close()


def _seed(conn: sqlite3.Connection) -> None:
    conn.execute("DELETE FROM rules")
    conn.execute("DELETE FROM jurisdictions")
    conn.execute("DELETE FROM products")
    conn.executemany(
        "INSERT INTO products (sku, name, unit_price, tax_category) VALUES (?, ?, ?, ?)",
        SEED_PRODUCTS,
    )
    conn.executemany(
        "INSERT INTO jurisdictions (code, name, default_rate, rates) VALUES (?, ?, ?, ?)",
        SEED_JURISDICTIONS,
    )
    conn.executemany(
        """INSERT INTO rules (rule_id, kind, sku, percent, buy, pay, tiers, code, amount)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        SEED_RULES,
    )
    conn.commit()


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = _connect(current_app.config["DATABASE"])
    return g.db


def close_connection(exception=None) -> None:
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


# -- products -----------------------------------------------------------

def _row_to_product(row) -> Product:
    return Product(row["sku"], row["name"], Decimal(row["unit_price"]), row["tax_category"])


def list_products(conn) -> list:
    rows = conn.execute("SELECT * FROM products ORDER BY sku").fetchall()
    return [_row_to_product(r) for r in rows]


def get_product(conn, sku: str):
    row = conn.execute("SELECT * FROM products WHERE sku = ?", (sku,)).fetchone()
    return _row_to_product(row) if row else None


def get_products_map(conn) -> dict:
    return {p.sku: p for p in list_products(conn)}


def insert_product(conn, product: Product) -> None:
    conn.execute(
        "INSERT INTO products (sku, name, unit_price, tax_category) VALUES (?, ?, ?, ?)",
        (product.sku, product.name, _money(product.unit_price), product.tax_category),
    )
    conn.commit()


def delete_product(conn, sku: str) -> bool:
    cur = conn.execute("DELETE FROM products WHERE sku = ?", (sku,))
    conn.commit()
    return cur.rowcount > 0


# -- jurisdictions --------------------------------------------------------

def _row_to_jurisdiction(row) -> Jurisdiction:
    from .formatting import parse_rates

    return Jurisdiction(row["code"], row["name"], parse_rates(row["rates"]), Decimal(row["default_rate"]))


def list_jurisdictions(conn) -> list:
    rows = conn.execute("SELECT * FROM jurisdictions ORDER BY code").fetchall()
    return [_row_to_jurisdiction(r) for r in rows]


def get_jurisdiction(conn, code: str):
    row = conn.execute("SELECT * FROM jurisdictions WHERE code = ?", (code,)).fetchone()
    return _row_to_jurisdiction(row) if row else None


def insert_jurisdiction(conn, jurisdiction: Jurisdiction) -> None:
    from .formatting import format_rates

    conn.execute(
        "INSERT INTO jurisdictions (code, name, default_rate, rates) VALUES (?, ?, ?, ?)",
        (
            jurisdiction.code,
            jurisdiction.name,
            _money(jurisdiction.default_rate),
            format_rates(jurisdiction.rates),
        ),
    )
    conn.commit()


def delete_jurisdiction(conn, code: str) -> bool:
    cur = conn.execute("DELETE FROM jurisdictions WHERE code = ?", (code,))
    conn.commit()
    return cur.rowcount > 0


# -- rules ----------------------------------------------------------------

def _row_to_rule(row):
    kind = row["kind"]
    if kind == "tiered":
        return TieredRule(row["rule_id"], row["sku"], parse_tiers(row["tiers"]))
    if kind == "bulk":
        return BulkRule(row["rule_id"], row["sku"], row["buy"], row["pay"])
    if kind == "percentage":
        return PercentageRule(row["rule_id"], Decimal(row["percent"]), row["sku"])
    if kind == "coupon":
        percent = Decimal(row["percent"]) if row["percent"] is not None else None
        amount = Decimal(row["amount"]) if row["amount"] is not None else None
        return CouponRule(row["rule_id"], row["code"], percent=percent, amount=amount)
    raise ValueError(f"unknown rule kind {kind!r}")


def _rule_to_row(rule):
    if isinstance(rule, TieredRule):
        return (rule.rule_id, "tiered", rule.sku, None, None, None, format_tiers(rule.tiers), None, None)
    if isinstance(rule, BulkRule):
        return (rule.rule_id, "bulk", rule.sku, None, rule.buy, rule.pay, None, None, None)
    if isinstance(rule, PercentageRule):
        return (rule.rule_id, "percentage", rule.sku, str(rule.percent), None, None, None, None, None)
    if isinstance(rule, CouponRule):
        percent = str(rule.percent) if rule.percent is not None else None
        amount = str(rule.amount) if rule.amount is not None else None
        return (rule.rule_id, "coupon", None, percent, None, None, None, rule.code, amount)
    raise TypeError(f"unknown rule type {type(rule)!r}")


def list_rules(conn) -> list:
    rows = conn.execute("SELECT * FROM rules ORDER BY rule_id").fetchall()
    return [_row_to_rule(r) for r in rows]


def rule_exists(conn, rule_id: str) -> bool:
    row = conn.execute("SELECT 1 FROM rules WHERE rule_id = ?", (rule_id,)).fetchone()
    return row is not None


def insert_rule(conn, rule) -> None:
    conn.execute(
        """INSERT INTO rules (rule_id, kind, sku, percent, buy, pay, tiers, code, amount)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        _rule_to_row(rule),
    )
    conn.commit()


def delete_rule(conn, rule_id: str) -> bool:
    cur = conn.execute("DELETE FROM rules WHERE rule_id = ?", (rule_id,))
    conn.commit()
    return cur.rowcount > 0


# -- invoices ---------------------------------------------------------------

def save_invoice(conn, priced, jurisdiction_code: str, coupon_codes) -> int:
    cur = conn.execute(
        """INSERT INTO invoices
           (currency, jurisdiction_code, jurisdiction_name, coupon_codes, applied,
            subtotal, discount_total, taxable_total, tax_total, total)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            priced.currency,
            jurisdiction_code,
            priced.jurisdiction.name,
            format_coupon_codes(coupon_codes),
            ",".join(priced.applied),
            _money(priced.subtotal),
            _money(priced.discount_total),
            _money(priced.taxable_total),
            _money(priced.tax_total),
            _money(priced.total),
        ),
    )
    invoice_id = cur.lastrowid
    for position, line in enumerate(priced.lines):
        conn.execute(
            """INSERT INTO invoice_lines
               (invoice_id, position, sku, name, quantity, unit_price, gross, line_discount,
                net, invoice_discount, taxable, tax, total, applied)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                invoice_id,
                position,
                line.product.sku,
                line.product.name,
                line.quantity,
                _money(line.product.unit_price),
                _money(line.gross),
                _money(line.line_discount),
                _money(line.net),
                _money(line.invoice_discount),
                _money(line.taxable),
                _money(line.tax),
                _money(line.total),
                ",".join(line.applied),
            ),
        )
    conn.commit()
    return invoice_id


def get_invoice(conn, invoice_id: int):
    header = conn.execute("SELECT * FROM invoices WHERE id = ?", (invoice_id,)).fetchone()
    if header is None:
        return None
    lines = conn.execute(
        "SELECT * FROM invoice_lines WHERE invoice_id = ? ORDER BY position", (invoice_id,)
    ).fetchall()
    return {"header": header, "lines": lines}
