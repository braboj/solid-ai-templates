from decimal import Decimal, InvalidOperation

from flask import Blueprint, abort, redirect, render_template, request, url_for

from ...errors import ValidationError
from ...rules import BulkRule, CouponRule, PercentageRule, TieredRule
from .. import db
from ..formatting import FieldError, parse_tiers

bp = Blueprint("rules", __name__)

KINDS = ("percentage", "bulk", "tiered", "coupon")


def _render(errors=None, form_data=None, status=200):
    conn = db.get_db()
    return (
        render_template(
            "rules.html",
            rules=db.list_rules(conn),
            errors=errors or [],
            form_data=form_data or {},
            kinds=KINDS,
        ),
        status,
    )


def _parse_decimal_field(form, field, errors, required=True):
    raw = (form.get(field) or "").strip()
    if not raw:
        if required:
            errors.append({"field": field, "message": f"{field} is required"})
        return None
    try:
        return Decimal(raw)
    except InvalidOperation:
        errors.append({"field": field, "message": f"{field} must be a number"})
        return None


def _parse_int_field(form, field, errors, required=True):
    raw = (form.get(field) or "").strip()
    if not raw:
        if required:
            errors.append({"field": field, "message": f"{field} is required"})
        return None
    try:
        return int(raw)
    except ValueError:
        errors.append({"field": field, "message": f"{field} must be a whole number"})
        return None


def _build_rule(kind, rule_id, form, errors):
    sku = (form.get("sku") or "").strip() or None

    if kind == "percentage":
        percent = _parse_decimal_field(form, "percent", errors)
        if errors:
            return None
        try:
            return PercentageRule(rule_id, percent, sku)
        except ValidationError as exc:
            errors.append({"field": "percent", "message": str(exc)})
            return None

    if kind == "bulk":
        if not sku:
            errors.append({"field": "sku", "message": "sku is required for a bulk rule"})
        buy = _parse_int_field(form, "buy", errors)
        pay = _parse_int_field(form, "pay", errors)
        if errors:
            return None
        try:
            return BulkRule(rule_id, sku, buy, pay)
        except ValidationError as exc:
            errors.append({"field": "pay", "message": str(exc)})
            return None

    if kind == "tiered":
        if not sku:
            errors.append({"field": "sku", "message": "sku is required for a tiered rule"})
        tiers_raw = form.get("tiers") or ""
        try:
            tiers = parse_tiers(tiers_raw)
        except FieldError as exc:
            errors.append({"field": "tiers", "message": str(exc)})
            tiers = None
        if errors:
            return None
        try:
            return TieredRule(rule_id, sku, tiers)
        except ValidationError as exc:
            errors.append({"field": "tiers", "message": str(exc)})
            return None

    if kind == "coupon":
        code = (form.get("code") or "").strip()
        if not code:
            errors.append({"field": "code", "message": "code is required for a coupon rule"})
        percent = _parse_decimal_field(form, "percent", errors, required=False)
        amount = _parse_decimal_field(form, "amount", errors, required=False)
        if errors:
            return None
        try:
            return CouponRule(rule_id, code, percent=percent, amount=amount)
        except ValidationError as exc:
            errors.append({"field": "amount", "message": str(exc)})
            return None

    errors.append({"field": "kind", "message": f"unknown kind {kind!r}"})
    return None


@bp.get("/rules")
def index():
    return _render()


@bp.post("/rules")
def create():
    conn = db.get_db()
    form = request.form
    rule_id = (form.get("rule_id") or "").strip()
    kind = (form.get("kind") or "").strip()

    errors = []
    if not rule_id:
        errors.append({"field": "rule_id", "message": "rule_id is required"})
    elif db.rule_exists(conn, rule_id):
        errors.append({"field": "rule_id", "message": f"rule_id {rule_id!r} already exists"})
    if kind not in KINDS:
        errors.append({"field": "kind", "message": "kind must be one of " + ", ".join(KINDS)})

    if errors:
        return _render(errors=errors, form_data=form)

    rule = _build_rule(kind, rule_id, form, errors)
    if errors or rule is None:
        return _render(errors=errors, form_data=form)

    db.insert_rule(conn, rule)
    return redirect(url_for("rules.index"), code=303)


@bp.post("/rules/<rule_id>/delete")
def delete(rule_id):
    conn = db.get_db()
    if not db.delete_rule(conn, rule_id):
        abort(404)
    return redirect(url_for("rules.index"), code=303)
