import csv
import io
import json
from decimal import Decimal

from flask import Blueprint, Response, abort, redirect, render_template, request, url_for

from ...errors import PricingError
from ...models import Invoice, InvoiceLine
from ...pricing import price
from .. import db
from ..formatting import parse_coupon_codes

bp = Blueprint("invoices", __name__)

ROWS = 12


class _BadRequest(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message


def _split_lines_form(form):
    skus = form.getlist("sku")
    quantities = form.getlist("quantity")
    count = max(len(skus), len(quantities))
    pairs = []
    errors = []
    for i in range(count):
        sku_raw = skus[i] if i < len(skus) else ""
        qty_raw = quantities[i] if i < len(quantities) else ""
        sku = sku_raw.strip()
        qty = qty_raw.strip()
        if not sku and not qty:
            continue
        if not sku:
            errors.append({"field": "sku", "message": f"line {i + 1}: sku is required"})
            continue
        if not qty:
            errors.append({"field": "quantity", "message": f"line {i + 1}: quantity is required"})
            continue
        try:
            qty_int = int(qty)
        except ValueError:
            errors.append({"field": "quantity", "message": f"line {i + 1}: quantity must be a whole number"})
            continue
        pairs.append({"sku": sku, "quantity": qty_int})
    return pairs, errors


def _gather(form):
    currency = (form.get("currency") or "").strip() or "EUR"
    jurisdiction_code = (form.get("jurisdiction") or "").strip()
    coupon_raw = form.get("coupon_codes") or ""
    coupon_codes = parse_coupon_codes(coupon_raw)
    pairs, errors = _split_lines_form(form)
    if not jurisdiction_code:
        errors.append({"field": "jurisdiction", "message": "jurisdiction is required"})
    return {
        "currency": currency,
        "jurisdiction_code": jurisdiction_code,
        "coupon_codes": coupon_codes,
        "coupon_raw": coupon_raw,
        "pairs": pairs,
        "errors": errors,
    }


def _price_from_gathered(conn, gathered, allow_empty):
    errors = list(gathered["errors"])
    if errors:
        return {"kind": "form_error", "errors": errors}

    jurisdiction = db.get_jurisdiction(conn, gathered["jurisdiction_code"])
    if jurisdiction is None:
        raise _BadRequest(f"unknown jurisdiction code {gathered['jurisdiction_code']!r}")

    products = db.get_products_map(conn)
    lines = []
    for pair in gathered["pairs"]:
        product = products.get(pair["sku"])
        if product is None:
            raise _BadRequest(f"unknown sku {pair['sku']!r}")
        if pair["quantity"] < 1:
            raise _BadRequest("quantity must be at least one")
        lines.append(InvoiceLine(product, pair["quantity"]))

    if not lines:
        if allow_empty:
            return {"kind": "empty"}
        raise _BadRequest("invoice has no lines")

    invoice = Invoice(gathered["currency"], lines, tuple(gathered["coupon_codes"]))
    rules = db.list_rules(conn)
    try:
        priced = price(invoice, rules, jurisdiction)
    except PricingError as exc:
        return {"kind": "form_error", "errors": [{"field": "coupon_codes", "message": str(exc)}]}

    return {
        "kind": "ok",
        "priced": priced,
        "jurisdiction": jurisdiction,
        "coupon_codes": gathered["coupon_codes"],
    }


def _padded_rows(pairs):
    rows = [{"sku": p["sku"], "quantity": str(p["quantity"])} for p in pairs]
    while len(rows) < ROWS:
        rows.append({"sku": "", "quantity": ""})
    return rows


def _render_fragment(priced=None, message=None, errors=None, bad_request=None):
    return render_template(
        "_priced_fragment.html",
        priced=priced,
        message=message,
        errors=errors or [],
        bad_request=bad_request,
    )


def _render_response(conn, gathered, is_htmx, priced=None, message=None, errors=None, bad_request=None):
    status = 400 if bad_request else 200
    fragment_html = _render_fragment(priced=priced, message=message, errors=errors, bad_request=bad_request)
    if is_htmx:
        return fragment_html, status
    jurisdictions = db.list_jurisdictions(conn)
    products = db.list_products(conn)
    rows = _padded_rows(gathered["pairs"])
    return (
        render_template(
            "invoice_builder.html",
            jurisdictions=jurisdictions,
            products=products,
            rows=rows,
            currency=gathered["currency"],
            jurisdiction_code=gathered["jurisdiction_code"],
            coupon_raw=gathered["coupon_raw"],
            fragment=fragment_html,
        ),
        status,
    )


def _is_htmx(req):
    return req.headers.get("HX-Request", "").lower() == "true"


@bp.get("/invoices/new")
def new():
    conn = db.get_db()
    jurisdictions = db.list_jurisdictions(conn)
    products = db.list_products(conn)
    rows = _padded_rows([])
    fragment_html = _render_fragment(message="Add lines and choose a jurisdiction to price this invoice.")
    return render_template(
        "invoice_builder.html",
        jurisdictions=jurisdictions,
        products=products,
        rows=rows,
        currency="EUR",
        jurisdiction_code="",
        coupon_raw="",
        fragment=fragment_html,
    )


@bp.post("/invoices/preview")
def preview():
    conn = db.get_db()
    gathered = _gather(request.form)
    is_htmx = _is_htmx(request)
    try:
        result = _price_from_gathered(conn, gathered, allow_empty=True)
    except _BadRequest as exc:
        return _render_response(conn, gathered, is_htmx, bad_request=exc.message)

    if result["kind"] == "form_error":
        return _render_response(conn, gathered, is_htmx, errors=result["errors"])
    if result["kind"] == "empty":
        return _render_response(conn, gathered, is_htmx, message="Add at least one line to price this invoice.")
    return _render_response(conn, gathered, is_htmx, priced=result["priced"])


@bp.post("/invoices")
def save():
    conn = db.get_db()
    gathered = _gather(request.form)
    is_htmx = _is_htmx(request)
    try:
        result = _price_from_gathered(conn, gathered, allow_empty=False)
    except _BadRequest as exc:
        return _render_response(conn, gathered, is_htmx, bad_request=exc.message)

    if result["kind"] == "form_error":
        return _render_response(conn, gathered, is_htmx, errors=result["errors"])

    invoice_id = db.save_invoice(
        conn,
        result["priced"],
        jurisdiction_code=result["jurisdiction"].code,
        coupon_codes=result["coupon_codes"],
    )
    return redirect(url_for("invoices.view", invoice_id=invoice_id), code=303)


@bp.get("/invoices/<int:invoice_id>")
def view(invoice_id):
    conn = db.get_db()
    data = db.get_invoice(conn, invoice_id)
    if data is None:
        abort(404)
    return render_template("invoice_view.html", header=data["header"], lines=data["lines"], invoice_id=invoice_id)


def _split_applied(raw):
    return [x for x in raw.split(",") if x] if raw else []


@bp.get("/invoices/<int:invoice_id>/export.json")
def export_json(invoice_id):
    conn = db.get_db()
    data = db.get_invoice(conn, invoice_id)
    if data is None:
        abort(404)
    header = data["header"]
    lines = data["lines"]
    payload = {
        "invoice_id": invoice_id,
        "currency": header["currency"],
        "jurisdiction": header["jurisdiction_code"],
        "lines": [
            {
                "sku": line["sku"],
                "name": line["name"],
                "quantity": line["quantity"],
                "unit_price": line["unit_price"],
                "gross": line["gross"],
                "line_discount": line["line_discount"],
                "net": line["net"],
                "invoice_discount": line["invoice_discount"],
                "taxable": line["taxable"],
                "tax": line["tax"],
                "total": line["total"],
                "applied": _split_applied(line["applied"]),
            }
            for line in lines
        ],
        "subtotal": header["subtotal"],
        "discount_total": header["discount_total"],
        "taxable_total": header["taxable_total"],
        "tax_total": header["tax_total"],
        "total": header["total"],
        "applied": _split_applied(header["applied"]),
    }
    body = json.dumps(payload)
    return Response(body, content_type="application/json")


@bp.get("/invoices/<int:invoice_id>/export.csv")
def export_csv(invoice_id):
    conn = db.get_db()
    data = db.get_invoice(conn, invoice_id)
    if data is None:
        abort(404)
    header = data["header"]
    lines = data["lines"]

    buf = io.StringIO(newline="")
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow(
        [
            "sku", "name", "quantity", "unit_price", "gross", "line_discount",
            "net", "invoice_discount", "taxable", "tax", "total",
        ]
    )
    gross_sum = Decimal("0.00")
    discount_sum = Decimal("0.00")
    for line in lines:
        writer.writerow(
            [
                line["sku"], line["name"], line["quantity"], line["unit_price"],
                line["gross"], line["line_discount"], line["net"], line["invoice_discount"],
                line["taxable"], line["tax"], line["total"],
            ]
        )
        gross_sum += Decimal(line["gross"])
        discount_sum += Decimal(line["line_discount"])
    writer.writerow(
        [
            "TOTAL", "", "", "",
            format(gross_sum, "f"),
            format(discount_sum, "f"),
            header["subtotal"],
            header["discount_total"],
            header["taxable_total"],
            header["tax_total"],
            header["total"],
        ]
    )
    body = buf.getvalue()
    return Response(body, content_type="text/csv; charset=utf-8")


@bp.get("/invoices/<int:invoice_id>/print")
def print_view(invoice_id):
    conn = db.get_db()
    data = db.get_invoice(conn, invoice_id)
    if data is None:
        abort(404)
    return render_template("invoice_print.html", header=data["header"], lines=data["lines"], invoice_id=invoice_id)
