from decimal import Decimal, InvalidOperation

from flask import Blueprint, abort, redirect, render_template, request, url_for

from ...errors import ValidationError
from ...models import Jurisdiction
from .. import db
from ..formatting import FieldError, parse_rates

bp = Blueprint("jurisdictions", __name__)


def _render(errors=None, form_data=None, status=200):
    conn = db.get_db()
    return (
        render_template(
            "jurisdictions.html",
            jurisdictions=db.list_jurisdictions(conn),
            errors=errors or [],
            form_data=form_data or {},
        ),
        status,
    )


@bp.get("/jurisdictions")
def index():
    return _render()


@bp.post("/jurisdictions")
def create():
    conn = db.get_db()
    form = request.form
    code = (form.get("code") or "").strip()
    name = (form.get("name") or "").strip()
    default_rate_raw = (form.get("default_rate") or "").strip()
    rates_raw = form.get("rates") or ""

    errors = []
    if not code:
        errors.append({"field": "code", "message": "code is required"})
    elif db.get_jurisdiction(conn, code) is not None:
        errors.append({"field": "code", "message": f"code {code!r} already exists"})
    if not name:
        errors.append({"field": "name", "message": "name is required"})

    default_rate = None
    if not default_rate_raw:
        errors.append({"field": "default_rate", "message": "default_rate is required"})
    else:
        try:
            default_rate = Decimal(default_rate_raw)
        except InvalidOperation:
            errors.append({"field": "default_rate", "message": "default_rate must be a number"})

    rates = {}
    try:
        rates = parse_rates(rates_raw)
    except FieldError as exc:
        errors.append({"field": "rates", "message": str(exc)})

    if errors:
        return _render(errors=errors, form_data=form)

    try:
        jurisdiction = Jurisdiction(code, name, rates, default_rate)
    except ValidationError as exc:
        errors.append({"field": "code", "message": str(exc)})
        return _render(errors=errors, form_data=form)

    db.insert_jurisdiction(conn, jurisdiction)
    return redirect(url_for("jurisdictions.index"), code=303)


@bp.post("/jurisdictions/<code>/delete")
def delete(code):
    conn = db.get_db()
    if not db.delete_jurisdiction(conn, code):
        abort(404)
    return redirect(url_for("jurisdictions.index"), code=303)
