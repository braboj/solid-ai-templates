from decimal import Decimal, InvalidOperation

from flask import Blueprint, abort, redirect, render_template, request, url_for

from ...models import Product
from ...errors import ValidationError
from .. import db

bp = Blueprint("products", __name__)


def _render(errors=None, form_data=None, status=200):
    conn = db.get_db()
    return (
        render_template(
            "products.html",
            products=db.list_products(conn),
            errors=errors or [],
            form_data=form_data or {},
        ),
        status,
    )


@bp.get("/products")
def index():
    return _render()


@bp.post("/products")
def create():
    conn = db.get_db()
    form = request.form
    sku = (form.get("sku") or "").strip()
    name = (form.get("name") or "").strip()
    unit_price_raw = (form.get("unit_price") or "").strip()
    tax_category = (form.get("tax_category") or "").strip()

    errors = []
    if not sku:
        errors.append({"field": "sku", "message": "sku is required"})
    elif db.get_product(conn, sku) is not None:
        errors.append({"field": "sku", "message": f"sku {sku!r} already exists"})
    if not name:
        errors.append({"field": "name", "message": "name is required"})
    if not tax_category:
        errors.append({"field": "tax_category", "message": "tax_category is required"})

    unit_price = None
    if not unit_price_raw:
        errors.append({"field": "unit_price", "message": "unit_price is required"})
    else:
        try:
            unit_price = Decimal(unit_price_raw)
        except InvalidOperation:
            errors.append({"field": "unit_price", "message": "unit_price must be a number"})

    if not errors:
        try:
            product = Product(sku, name, unit_price, tax_category)
        except ValidationError as exc:
            errors.append({"field": "unit_price", "message": str(exc)})
        else:
            db.insert_product(conn, product)
            return redirect(url_for("products.index"), code=303)

    return _render(errors=errors, form_data=form)


@bp.post("/products/<sku>/delete")
def delete(sku):
    conn = db.get_db()
    if not db.delete_product(conn, sku):
        abort(404)
    return redirect(url_for("products.index"), code=303)
