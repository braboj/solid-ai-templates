"""The pricing algorithm: price(invoice, rules, jurisdiction) -> PricedInvoice."""

from dataclasses import dataclass
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_EVEN

from .errors import PricingError
from .models import Jurisdiction, Product
from .rules import BulkRule, CouponRule, PercentageRule, TieredRule

TWO_PLACES = Decimal("0.01")


def _round2(value: Decimal) -> Decimal:
    return value.quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)


@dataclass
class PricedLine:
    product: Product
    quantity: int
    gross: Decimal
    line_discount: Decimal
    net: Decimal
    invoice_discount: Decimal
    taxable: Decimal
    tax: Decimal
    total: Decimal
    applied: list


@dataclass
class PricedInvoice:
    currency: str
    jurisdiction: Jurisdiction
    lines: list
    subtotal: Decimal
    discount_total: Decimal
    taxable_total: Decimal
    tax_total: Decimal
    total: Decimal
    applied: list


@dataclass
class _LineWork:
    product: Product
    quantity: int
    gross: Decimal
    line_discount: Decimal
    net: Decimal
    applied: list


def _apply_tiered(rule: TieredRule, amount: Decimal, quantity: int) -> Decimal:
    applicable_price = None
    for min_quantity, unit_price in rule.tiers:
        if quantity >= min_quantity:
            applicable_price = unit_price
    if applicable_price is None:
        return amount
    return applicable_price * quantity


def _apply_bulk(rule: BulkRule, amount: Decimal, quantity: int) -> Decimal:
    groups, remainder = divmod(quantity, rule.buy)
    chargeable_units = groups * rule.pay + remainder
    return amount / quantity * chargeable_units


def _apply_percentage(percent: Decimal, amount: Decimal) -> Decimal:
    return amount * (Decimal(1) - percent / Decimal(100))


def _select(options):
    """options: list of (amount, rule). Returns the (amount, rule) with the
    lowest amount, ties broken by rule_id ascending."""
    return min(options, key=lambda pair: (pair[0], pair[1].rule_id))


def _price_line(line, rules) -> _LineWork:
    product = line.product
    quantity = line.quantity
    if quantity < 1:
        raise PricingError("line quantity must be at least one")

    gross = product.unit_price * quantity
    amount = gross
    applied: list[str] = []

    tiered_candidates = [r for r in rules if isinstance(r, TieredRule) and r.sku == product.sku]
    if tiered_candidates:
        options = [(_apply_tiered(r, amount, quantity), r) for r in tiered_candidates]
        amount, rule = _select(options)
        applied.append(rule.rule_id)

    bulk_candidates = [r for r in rules if isinstance(r, BulkRule) and r.sku == product.sku]
    if bulk_candidates:
        options = [(_apply_bulk(r, amount, quantity), r) for r in bulk_candidates]
        amount, rule = _select(options)
        applied.append(rule.rule_id)

    pct_candidates = [r for r in rules if isinstance(r, PercentageRule) and r.sku == product.sku]
    if pct_candidates:
        options = [(_apply_percentage(r.percent, amount), r) for r in pct_candidates]
        amount, rule = _select(options)
        applied.append(rule.rule_id)

    net = _round2(amount)
    gross_rounded = _round2(gross)
    line_discount = gross_rounded - net

    return _LineWork(
        product=product,
        quantity=quantity,
        gross=gross,
        line_discount=line_discount,
        net=net,
        applied=applied,
    )


def _allocate(discount_total: Decimal, subtotal: Decimal, nets: list) -> list:
    count = len(nets)
    if subtotal == 0:
        return [Decimal("0.00")] * count

    exact_shares = [discount_total * net / subtotal for net in nets]
    truncated = [share.quantize(TWO_PLACES, rounding=ROUND_DOWN) for share in exact_shares]
    remainder_fracs = [share - trunc for share, trunc in zip(exact_shares, truncated)]

    total_truncated = sum(truncated, Decimal("0.00"))
    cents_short = int((discount_total - total_truncated) * 100)

    order = sorted(range(count), key=lambda i: (-remainder_fracs[i], i))
    receives_extra_cent = set(order[:cents_short])

    allocations = []
    for i in range(count):
        amount = truncated[i]
        if i in receives_extra_cent:
            amount += TWO_PLACES
        allocations.append(amount)
    return allocations


def price(invoice, rules, jurisdiction) -> PricedInvoice:
    if not invoice.lines:
        raise PricingError("invoice has no lines")

    rule_ids = [r.rule_id for r in rules]
    if len(rule_ids) != len(set(rule_ids)):
        raise PricingError("two rules share a rule_id")

    coupon_rules = [r for r in rules if isinstance(r, CouponRule)]
    known_codes = {r.code.strip() for r in coupon_rules}
    for code in invoice.coupon_codes:
        if code.strip() not in known_codes:
            raise PricingError(f"unknown coupon code {code!r}")

    line_work = [_price_line(line, rules) for line in invoice.lines]
    subtotal = sum((lw.net for lw in line_work), Decimal("0.00"))

    running = subtotal
    applied_invoice: list[str] = []

    pct_candidates = [r for r in rules if isinstance(r, PercentageRule) and r.sku is None]
    if pct_candidates:
        options = [(_round2(_apply_percentage(r.percent, running)), r) for r in pct_candidates]
        running, rule = _select(options)
        applied_invoice.append(rule.rule_id)

    carried_codes = {c.strip() for c in invoice.coupon_codes}
    coupon_candidates = [r for r in coupon_rules if r.code.strip() in carried_codes]
    if coupon_candidates:
        options = []
        for r in coupon_candidates:
            if r.percent is not None:
                amount = _round2(_apply_percentage(r.percent, running))
            else:
                amount = _round2(running - min(r.amount, running))
            options.append((amount, r))
        running, rule = _select(options)
        applied_invoice.append(rule.rule_id)

    discounted_subtotal = running
    discount_total = subtotal - discounted_subtotal

    allocations = _allocate(discount_total, subtotal, [lw.net for lw in line_work])

    priced_lines = []
    tax_total = Decimal("0.00")
    for lw, allocated in zip(line_work, allocations):
        taxable = lw.net - allocated
        rate = jurisdiction.rates.get(lw.product.tax_category, jurisdiction.default_rate)
        tax = _round2(taxable * rate)
        total = taxable + tax
        tax_total += tax
        priced_lines.append(
            PricedLine(
                product=lw.product,
                quantity=lw.quantity,
                gross=lw.gross,
                line_discount=lw.line_discount,
                net=lw.net,
                invoice_discount=allocated,
                taxable=taxable,
                tax=tax,
                total=total,
                applied=lw.applied,
            )
        )

    total = discounted_subtotal + tax_total

    return PricedInvoice(
        currency=invoice.currency,
        jurisdiction=jurisdiction,
        lines=priced_lines,
        subtotal=subtotal,
        discount_total=discount_total,
        taxable_total=discounted_subtotal,
        tax_total=tax_total,
        total=total,
        applied=applied_invoice,
    )
