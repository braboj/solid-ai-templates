"""Discount rules: percentage, bulk, tiered and coupon."""

from dataclasses import dataclass
from decimal import Decimal

from .errors import ValidationError


@dataclass
class PercentageRule:
    rule_id: str
    percent: Decimal
    sku: str | None = None

    def __post_init__(self) -> None:
        if not self.percent > 0 or self.percent > 100:
            raise ValidationError("percent must be greater than zero and at most 100")


@dataclass
class BulkRule:
    rule_id: str
    sku: str
    buy: int
    pay: int

    def __post_init__(self) -> None:
        if self.pay < 1 or not self.buy > self.pay:
            raise ValidationError("buy must be greater than pay, and pay must be at least one")


@dataclass
class TieredRule:
    rule_id: str
    sku: str
    tiers: tuple

    def __post_init__(self) -> None:
        tiers = tuple((int(min_quantity), Decimal(unit_price)) for min_quantity, unit_price in self.tiers)
        if not tiers:
            raise ValidationError("tiers must not be empty")
        previous = None
        for min_quantity, unit_price in tiers:
            if min_quantity < 1:
                raise ValidationError("tier min_quantity must be at least one")
            if unit_price < 0:
                raise ValidationError("tier unit_price must not be negative")
            if previous is not None and min_quantity <= previous:
                raise ValidationError("tiers must be strictly increasing by min_quantity")
            previous = min_quantity
        self.tiers = tiers


@dataclass
class CouponRule:
    rule_id: str
    code: str
    percent: Decimal | None = None
    amount: Decimal | None = None

    def __post_init__(self) -> None:
        if not self.code:
            raise ValidationError("code must be non-empty")
        if (self.percent is None) == (self.amount is None):
            raise ValidationError("coupon must carry exactly one of percent or amount")
        if self.amount is not None and not self.amount > 0:
            raise ValidationError("amount must be greater than zero")
