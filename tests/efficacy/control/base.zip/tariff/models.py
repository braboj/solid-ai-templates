"""Core domain objects: Product, Catalog, InvoiceLine, Invoice, Jurisdiction."""

from dataclasses import dataclass, field
from decimal import Decimal

from .errors import CatalogError, ValidationError


@dataclass
class Product:
    sku: str
    name: str
    unit_price: Decimal
    tax_category: str

    def __post_init__(self) -> None:
        if not self.sku:
            raise ValidationError("sku must be non-empty")
        if not self.name:
            raise ValidationError("name must be non-empty")
        if not isinstance(self.unit_price, Decimal):
            raise ValidationError("unit_price must be a Decimal")
        if self.unit_price < 0:
            raise ValidationError("unit_price must be at least zero")
        if not self.tax_category:
            raise ValidationError("tax_category must be non-empty")


class Catalog:
    def __init__(self, products=()):
        self._products: dict[str, Product] = {}
        for product in products:
            self.add(product)

    def add(self, product: Product) -> None:
        if product.sku in self._products:
            raise ValidationError(f"duplicate sku {product.sku!r}")
        self._products[product.sku] = product

    def get(self, sku: str) -> Product:
        try:
            return self._products[sku]
        except KeyError:
            raise CatalogError(f"unknown sku {sku!r}") from None

    def __iter__(self):
        return iter(self._products.values())

    def __len__(self) -> int:
        return len(self._products)


@dataclass
class InvoiceLine:
    product: Product
    quantity: int

    def __post_init__(self) -> None:
        if self.quantity < 1:
            raise ValidationError("quantity must be at least one")


@dataclass
class Invoice:
    currency: str
    lines: list
    coupon_codes: tuple = ()


@dataclass
class Jurisdiction:
    code: str
    name: str
    rates: dict
    default_rate: Decimal

    def __post_init__(self) -> None:
        if not self.code:
            raise ValidationError("code must be non-empty")
        if not self.name:
            raise ValidationError("name must be non-empty")
