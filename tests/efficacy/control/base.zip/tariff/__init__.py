"""tariff: a pricing and invoicing engine, with an optional Flask web UI.

``import tariff`` works without Flask installed and without touching the
database: the web application is only imported when ``tariff.create_app``
is actually accessed.
"""

from .errors import CatalogError, PricingError, TariffError, ValidationError
from .models import Catalog, Invoice, InvoiceLine, Jurisdiction, Product
from .pricing import PricedInvoice, PricedLine, price
from .rules import BulkRule, CouponRule, PercentageRule, TieredRule

__all__ = [
    "Product",
    "Catalog",
    "InvoiceLine",
    "Invoice",
    "Jurisdiction",
    "PercentageRule",
    "BulkRule",
    "TieredRule",
    "CouponRule",
    "price",
    "PricedInvoice",
    "PricedLine",
    "TariffError",
    "ValidationError",
    "CatalogError",
    "PricingError",
    "create_app",
]


def __getattr__(name):
    if name == "create_app":
        from .web import create_app

        return create_app
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
