"""Exceptions raised by the tariff package.

Every exception the package raises on purpose derives from TariffError.
"""


class TariffError(Exception):
    """Base of every exception this package raises on purpose."""


class ValidationError(TariffError):
    """A domain object (product, rule, jurisdiction, ...) is invalid."""


class CatalogError(TariffError):
    """A catalog lookup failed."""


class PricingError(TariffError):
    """An invoice could not be priced."""
