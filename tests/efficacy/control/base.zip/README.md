# tariff

A pricing and invoicing engine, with a server-rendered Flask web UI for
managing products, discount rules and tax jurisdictions, and for building
and pricing invoices.

## Install

```
python -m venv .venv
.venv\Scripts\activate        # Windows
# source .venv/bin/activate   # macOS / Linux
pip install .
```

`import tariff` works standalone — it does not require Flask and does not
touch any database:

```
python -c "import tariff; print(tariff.price)"
```

## Run the web application

The web application needs Flask, which is a normal dependency of the
package (`pip install .` already installed it).

```
tariff-serve tariff.db
```

This starts a development server on `http://127.0.0.1:5000/`. On first run
it creates `tariff.db` and seeds it with the fixture described in
`SPEC.md` section 8 (five products, two jurisdictions, six discount rules).

To reset the database back to that fixture at any time:

```
tariff-seed tariff.db
```

## Using the pricing engine directly

```python
from decimal import Decimal
from tariff import (
    Product, Invoice, InvoiceLine, Jurisdiction,
    PercentageRule, BulkRule, TieredRule, CouponRule, price,
)

widget = Product("WID-1", "Widget", Decimal("10.00"), "standard")
de = Jurisdiction("DE", "Germany", {"standard": Decimal("0.19")}, Decimal("0.19"))
rules = [PercentageRule("r-pct-all", Decimal("5"))]

invoice = Invoice("EUR", [InvoiceLine(widget, 3)])
priced = price(invoice, rules, de)
print(priced.total)
```

## Web routes

| Method | Path | Purpose |
|---|---|---|
| GET | `/` | dashboard |
| GET/POST | `/products` | product list / create |
| POST | `/products/<sku>/delete` | delete a product |
| GET/POST | `/rules` | rule list / create |
| POST | `/rules/<rule_id>/delete` | delete a rule |
| GET/POST | `/jurisdictions` | jurisdiction list / create |
| POST | `/jurisdictions/<code>/delete` | delete a jurisdiction |
| GET | `/invoices/new` | invoice builder |
| POST | `/invoices/preview` | re-price the builder's current state |
| POST | `/invoices` | save the invoice |
| GET | `/invoices/<id>` | a saved invoice |
| GET | `/invoices/<id>/export.json` | JSON export |
| GET | `/invoices/<id>/export.csv` | CSV export |
| GET | `/invoices/<id>/print` | a printable invoice |

The invoice builder is a single HTML form; it works fully with JavaScript
disabled (every field submits and re-renders the whole page). With
JavaScript enabled, a small vendored script (`tariff/web/static/htmx.min.js`
— a minimal implementation of the subset of HTMX attributes this app uses:
`hx-post`, `hx-target`, `hx-swap`, `hx-trigger`, `hx-include`) re-prices the
invoice automatically as fields change, without a page reload.

## Tests

```
pip install '.[test]'
pytest
```
