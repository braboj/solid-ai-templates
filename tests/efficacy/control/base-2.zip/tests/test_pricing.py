from decimal import Decimal

import pytest

from tariff import (
    BulkRule,
    Catalog,
    CouponRule,
    Invoice,
    InvoiceLine,
    Jurisdiction,
    PercentageRule,
    PricingError,
    Product,
    TariffError,
    TieredRule,
    ValidationError,
    price,
)


@pytest.fixture
def products():
    return {
        "WID-1": Product("WID-1", "Widget", "10.00", "standard"),
        "GAD-2": Product("GAD-2", "Gadget", "24.50", "standard"),
        "BOK-3": Product("BOK-3", "Handbook", "12.00", "reduced"),
        "SRV-4": Product("SRV-4", "Support hour", "80.00", "standard"),
        "SEE-5": Product("SEE-5", "Seed pack", "3.75", "zero"),
    }


@pytest.fixture
def de(products):
    return Jurisdiction(
        "DE", "Germany", {"standard": "0.19", "reduced": "0.07", "zero": "0.00"}, "0.19"
    )


@pytest.fixture
def seed_rules():
    return [
        TieredRule("r-tier-wid", "WID-1", [(1, "10.00"), (10, "9.00"), (50, "8.00")]),
        BulkRule("r-bulk-see", "SEE-5", 3, 2),
        PercentageRule("r-pct-bok", "10", sku="BOK-3"),
        PercentageRule("r-pct-all", "5"),
        CouponRule("c-welcome", "WELCOME", percent="10"),
        CouponRule("c-tenoff", "TENOFF", amount="10.00"),
    ]


def test_worked_example(products, de, seed_rules):
    invoice = Invoice(
        "EUR",
        [
            InvoiceLine(products["WID-1"], 12),
            InvoiceLine(products["SEE-5"], 7),
            InvoiceLine(products["BOK-3"], 2),
            InvoiceLine(products["SRV-4"], 1),
        ],
        coupon_codes=["WELCOME"],
    )
    result = price(invoice, seed_rules, de)

    assert result.subtotal == Decimal("228.35")
    assert result.discount_total == Decimal("33.11")
    assert result.taxable_total == Decimal("195.24")
    assert result.tax_total == Decimal("31.83")
    assert result.total == Decimal("227.07")
    assert result.applied == ["r-pct-all", "c-welcome"]

    by_sku = {line.product.sku: line for line in result.lines}
    assert by_sku["WID-1"].net == Decimal("108.00")
    assert by_sku["WID-1"].invoice_discount == Decimal("15.66")
    assert by_sku["WID-1"].taxable == Decimal("92.34")
    assert by_sku["WID-1"].tax == Decimal("17.54")
    assert by_sku["WID-1"].total == Decimal("109.88")
    assert by_sku["WID-1"].applied == ["r-tier-wid"]

    assert by_sku["SEE-5"].net == Decimal("18.75")
    assert by_sku["SEE-5"].invoice_discount == Decimal("2.72")
    assert by_sku["SEE-5"].tax == Decimal("0.00")
    assert by_sku["SEE-5"].total == Decimal("16.03")

    assert by_sku["BOK-3"].net == Decimal("21.60")
    assert by_sku["BOK-3"].invoice_discount == Decimal("3.13")
    assert by_sku["BOK-3"].tax == Decimal("1.29")
    assert by_sku["BOK-3"].total == Decimal("19.76")

    assert by_sku["SRV-4"].net == Decimal("80.00")
    assert by_sku["SRV-4"].invoice_discount == Decimal("11.60")
    assert by_sku["SRV-4"].tax == Decimal("13.00")
    assert by_sku["SRV-4"].total == Decimal("81.40")


def test_gross_is_exact_not_rounded(products, de):
    product = Product("X", "X", "0.10", "standard")
    invoice = Invoice("EUR", [InvoiceLine(product, 3)])
    result = price(invoice, [], de)
    assert result.lines[0].gross == Decimal("0.30")


def test_tiered_rule_not_reached_still_applied(products, de):
    rule = TieredRule("t1", "WID-1", [(100, "1.00")])
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 5)])
    result = price(invoice, [rule], de)
    line = result.lines[0]
    assert line.applied == ["t1"]
    assert line.net == Decimal("50.00")  # unchanged: 5 * 10.00


def test_bulk_rule_math(products, de):
    rule = BulkRule("b1", "SEE-5", 3, 2)
    invoice = Invoice("EUR", [InvoiceLine(products["SEE-5"], 7)])
    result = price(invoice, [rule], de)
    line = result.lines[0]
    # groups=2, remainder=1, chargeable=2*2+1=5; 26.25/7*5 = 18.75
    assert line.net == Decimal("18.75")


def test_percentage_rule_scoped_to_invoice_not_applied_per_line(products, de):
    rule = PercentageRule("p1", "50")  # invoice scope
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)])
    result = price(invoice, [rule], de)
    line = result.lines[0]
    assert line.applied == []
    assert line.net == Decimal("10.00")
    assert result.applied == ["p1"]
    assert result.taxable_total == Decimal("5.00")
    assert result.total == Decimal("5.95")


def test_at_most_one_rule_per_kind_lowest_wins_tie_by_rule_id(products, de):
    r1 = PercentageRule("z-rule", "10", sku="WID-1")
    r2 = PercentageRule("a-rule", "10", sku="WID-1")  # identical result, lower rule_id wins
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)])
    result = price(invoice, [r1, r2], de)
    assert result.lines[0].applied == ["a-rule"]


def test_lowest_result_wins_over_rule_id(products, de):
    cheap = PercentageRule("z-rule", "50", sku="WID-1")  # bigger discount = lower result
    expensive = PercentageRule("a-rule", "5", sku="WID-1")
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)])
    result = price(invoice, [cheap, expensive], de)
    assert result.lines[0].applied == ["z-rule"]


def test_coupon_amount_never_negative(products, de):
    coupon = CouponRule("c1", "BIG", amount="1000.00")
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)], coupon_codes=["BIG"])
    result = price(invoice, [coupon], de)
    assert result.taxable_total == Decimal("0.00")
    assert result.total == Decimal("0.00")


def test_coupon_code_matched_after_stripping_whitespace(products, de):
    coupon = CouponRule("c1", "WELCOME", percent="10")
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)], coupon_codes=["  WELCOME  "])
    result = price(invoice, [coupon], de)
    assert result.applied == ["c1"]


def test_allocation_sums_exactly_to_discount_total(products, de):
    rule = PercentageRule("p1", "7")
    lines = [InvoiceLine(products["WID-1"], 3), InvoiceLine(products["SEE-5"], 5), InvoiceLine(products["BOK-3"], 1)]
    invoice = Invoice("EUR", lines)
    result = price(invoice, [rule], de)
    total_allocated = sum(line.invoice_discount for line in result.lines)
    assert total_allocated == result.discount_total


def test_allocation_zero_when_subtotal_zero(de):
    free = Product("FREE", "Free thing", "0.00", "standard")
    invoice = Invoice("EUR", [InvoiceLine(free, 5)])
    result = price(invoice, [], de)
    assert result.lines[0].invoice_discount == Decimal("0.00")


def test_tax_uses_default_rate_for_unknown_category(products):
    jurisdiction = Jurisdiction("XX", "X-land", {}, "0.20")
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)])
    result = price(invoice, [], jurisdiction)
    assert result.lines[0].tax == Decimal("2.00")


def test_refuses_no_lines(de):
    invoice = Invoice("EUR", [])
    with pytest.raises(PricingError):
        price(invoice, [], de)


def test_refuses_quantity_below_one_even_if_line_did_not_check(products, de):
    # InvoiceLine itself does not validate quantity; price() must refuse anyway.
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 0)])
    with pytest.raises(PricingError):
        price(invoice, [], de)


def test_refuses_duplicate_rule_id(products, de):
    r1 = PercentageRule("dup", "10", sku="WID-1")
    r2 = BulkRule("dup", "SEE-5", 3, 2)
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)])
    with pytest.raises(PricingError):
        price(invoice, [r1, r2], de)


def test_refuses_unknown_coupon_code(products, de):
    invoice = Invoice("EUR", [InvoiceLine(products["WID-1"], 1)], coupon_codes=["NOPE"])
    with pytest.raises(PricingError):
        price(invoice, [], de)


def test_every_raised_error_is_tariff_error():
    assert issubclass(PricingError, TariffError)
    assert issubclass(ValidationError, TariffError)


class TestRuleValidation:
    def test_percentage_rejects_zero(self):
        with pytest.raises(ValidationError):
            PercentageRule("r", "0")

    def test_percentage_rejects_over_100(self):
        with pytest.raises(ValidationError):
            PercentageRule("r", "101")

    def test_bulk_rejects_buy_not_greater_than_pay(self):
        with pytest.raises(ValidationError):
            BulkRule("r", "SKU", 2, 2)

    def test_bulk_rejects_pay_below_one(self):
        with pytest.raises(ValidationError):
            BulkRule("r", "SKU", 1, 0)

    def test_tiered_rejects_empty(self):
        with pytest.raises(ValidationError):
            TieredRule("r", "SKU", [])

    def test_tiered_rejects_non_increasing(self):
        with pytest.raises(ValidationError):
            TieredRule("r", "SKU", [(10, "1.00"), (5, "2.00")])

    def test_tiered_rejects_negative_price(self):
        with pytest.raises(ValidationError):
            TieredRule("r", "SKU", [(1, "-1.00")])

    def test_coupon_rejects_empty_code(self):
        with pytest.raises(ValidationError):
            CouponRule("r", "", percent="10")

    def test_coupon_rejects_both_percent_and_amount(self):
        with pytest.raises(ValidationError):
            CouponRule("r", "CODE", percent="10", amount="5.00")

    def test_coupon_rejects_neither_percent_nor_amount(self):
        with pytest.raises(ValidationError):
            CouponRule("r", "CODE")

    def test_coupon_rejects_non_positive_amount(self):
        with pytest.raises(ValidationError):
            CouponRule("r", "CODE", amount="0.00")


class TestModels:
    def test_catalog_get_unknown_sku_raises(self):
        catalog = Catalog()
        with pytest.raises(TariffError):
            catalog.get("NOPE")

    def test_catalog_add_duplicate_sku_raises(self):
        catalog = Catalog()
        catalog.add(Product("A", "A", "1.00", "standard"))
        with pytest.raises(ValidationError):
            catalog.add(Product("A", "B", "2.00", "standard"))

    def test_product_rejects_negative_price(self):
        with pytest.raises(ValidationError):
            Product("A", "A", "-1.00", "standard")

    def test_product_rejects_empty_name(self):
        with pytest.raises(ValidationError):
            Product("A", "", "1.00", "standard")

    def test_floats_are_rejected(self):
        with pytest.raises(ValidationError):
            Product("A", "A", 1.5, "standard")
