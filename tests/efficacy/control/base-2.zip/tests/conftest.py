import re

import pytest

from tariff import create_app
from tariff import db as db_module

ADMIN_PASSWORD = "correct horse battery staple"


@pytest.fixture
def db_path(tmp_path):
    return str(tmp_path / "tariff.db")


@pytest.fixture
def seeded_conn(db_path):
    conn = db_module.connect(db_path)
    db_module.seed(conn, ADMIN_PASSWORD)
    yield conn
    conn.close()


@pytest.fixture
def app(db_path, seeded_conn):
    application = create_app(db_path)
    application.testing = True
    return application


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def signed_in_client(client):
    sign_in(client)
    return client


def get_csrf(html):
    match = re.search(r'name="csrf_token" value="([^"]+)"', html)
    assert match, f"no csrf token found in page: {html[:300]}"
    return match.group(1)


def sign_in(client, password=ADMIN_PASSWORD):
    token = get_csrf(client.get("/sign-in").get_data(as_text=True))
    return client.post(
        "/sign-in",
        data={"username": "admin", "password": password, "next": "", "csrf_token": token},
        follow_redirects=False,
    )
