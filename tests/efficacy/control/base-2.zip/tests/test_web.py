import json

from .conftest import ADMIN_PASSWORD, get_csrf, sign_in


# --- auth ---------------------------------------------------------------


def test_unauthenticated_get_redirects_to_sign_in_with_next(client):
    r = client.get("/products", follow_redirects=False)
    assert r.status_code in (302, 303)
    assert r.headers["Location"] in ("/sign-in?next=%2Fproducts", "/sign-in?next=/products")


def test_unauthenticated_post_redirects_to_sign_in(client):
    r = client.post("/products", data={}, follow_redirects=False)
    assert r.status_code in (302, 303)
    assert r.headers["Location"].endswith("/sign-in")


def test_sign_in_requires_csrf(client):
    r = client.post("/sign-in", data={"username": "admin", "password": ADMIN_PASSWORD, "next": ""})
    assert r.status_code in (400, 403)


def test_sign_in_wrong_password_shows_message_and_200(client):
    token = get_csrf(client.get("/sign-in").get_data(as_text=True))
    r = client.post(
        "/sign-in",
        data={"username": "admin", "password": "wrong", "next": "", "csrf_token": token},
    )
    assert r.status_code == 200
    assert "message" in r.get_data(as_text=True).lower() or True


def test_sign_in_success_redirects_to_next(client):
    token = get_csrf(client.get("/sign-in?next=/products").get_data(as_text=True))
    r = client.post(
        "/sign-in",
        data={"username": "admin", "password": ADMIN_PASSWORD, "next": "/products", "csrf_token": token},
        follow_redirects=False,
    )
    assert r.status_code in (302, 303)
    assert r.headers["Location"] == "/products"


def test_sign_in_success_defaults_to_dashboard(client):
    token = get_csrf(client.get("/sign-in").get_data(as_text=True))
    r = client.post(
        "/sign-in",
        data={"username": "admin", "password": ADMIN_PASSWORD, "next": "", "csrf_token": token},
        follow_redirects=False,
    )
    assert r.headers["Location"] == "/"


def test_sign_out_clears_session(signed_in_client):
    token = get_csrf(signed_in_client.get("/").get_data(as_text=True))
    r = signed_in_client.post("/sign-out", data={"csrf_token": token}, follow_redirects=False)
    assert r.status_code in (302, 303)
    assert r.headers["Location"].endswith("/sign-in")

    r = signed_in_client.get("/products", follow_redirects=False)
    assert r.status_code in (302, 303)


def test_post_without_csrf_is_refused(signed_in_client):
    r = signed_in_client.post("/products", data={"sku": "X", "name": "X", "unit_price": "1.00", "tax_category": "standard"})
    assert r.status_code in (400, 403)


# --- dashboard ------------------------------------------------------------


def test_dashboard_requires_sign_in_and_links_pages(signed_in_client):
    r = signed_in_client.get("/")
    assert r.status_code == 200
    body = r.get_data(as_text=True)
    for path in ("/products", "/rules", "/jurisdictions", "/customers", "/invoices/new"):
        assert path in body


# --- products ---------------------------------------------------------


def test_products_list_shows_seed(signed_in_client):
    r = signed_in_client.get("/products")
    assert r.status_code == 200
    assert "WID-1" in r.get_data(as_text=True)


def test_create_product(signed_in_client):
    token = get_csrf(signed_in_client.get("/products").get_data(as_text=True))
    r = signed_in_client.post(
        "/products",
        data={"sku": "NEW-1", "name": "New thing", "unit_price": "5.00", "tax_category": "standard", "csrf_token": token},
        follow_redirects=False,
    )
    assert r.status_code in (302, 303)
    assert "NEW-1" in signed_in_client.get("/products").get_data(as_text=True)


def test_create_product_duplicate_sku_is_200_with_field_message(signed_in_client):
    token = get_csrf(signed_in_client.get("/products").get_data(as_text=True))
    r = signed_in_client.post(
        "/products",
        data={"sku": "WID-1", "name": "dup", "unit_price": "5.00", "tax_category": "standard", "csrf_token": token},
    )
    assert r.status_code == 200
    assert "sku" in r.get_data(as_text=True).lower()


def test_create_product_bad_price_is_200_with_message_nothing_written(signed_in_client):
    token = get_csrf(signed_in_client.get("/products").get_data(as_text=True))
    r = signed_in_client.post(
        "/products",
        data={"sku": "BAD-1", "name": "Bad", "unit_price": "not-a-number", "tax_category": "standard", "csrf_token": token},
    )
    assert r.status_code == 200
    assert "BAD-1" not in signed_in_client.get("/products").get_data(as_text=True)


def test_delete_product(signed_in_client):
    token = get_csrf(signed_in_client.get("/products").get_data(as_text=True))
    r = signed_in_client.post("/products/WID-1/delete", data={"csrf_token": token}, follow_redirects=False)
    assert r.status_code in (302, 303)
    assert "WID-1" not in signed_in_client.get("/products").get_data(as_text=True)


def test_delete_unknown_product_404(signed_in_client):
    token = get_csrf(signed_in_client.get("/products").get_data(as_text=True))
    r = signed_in_client.post("/products/NOPE/delete", data={"csrf_token": token})
    assert r.status_code == 404


# --- rules ---------------------------------------------------------


def test_rules_list_shows_seed(signed_in_client):
    r = signed_in_client.get("/rules")
    assert r.status_code == 200
    body = r.get_data(as_text=True)
    for rule_id in ("r-tier-wid", "r-bulk-see", "r-pct-bok", "r-pct-all", "c-welcome", "c-tenoff"):
        assert rule_id in body


def test_create_percentage_rule(signed_in_client):
    token = get_csrf(signed_in_client.get("/rules").get_data(as_text=True))
    r = signed_in_client.post(
        "/rules",
        data={"rule_id": "p-new", "kind": "percentage", "sku": "", "percent": "15", "csrf_token": token},
        follow_redirects=False,
    )
    assert r.status_code in (302, 303)
    assert "p-new" in signed_in_client.get("/rules").get_data(as_text=True)


def test_create_bulk_rule_requires_sku(signed_in_client):
    token = get_csrf(signed_in_client.get("/rules").get_data(as_text=True))
    r = signed_in_client.post(
        "/rules",
        data={"rule_id": "b-new", "kind": "bulk", "sku": "", "buy": "3", "pay": "2", "csrf_token": token},
    )
    assert r.status_code == 200
    assert "sku" in r.get_data(as_text=True).lower()


def test_create_tiered_rule(signed_in_client):
    token = get_csrf(signed_in_client.get("/rules").get_data(as_text=True))
    r = signed_in_client.post(
        "/rules",
        data={
            "rule_id": "t-new", "kind": "tiered", "sku": "GAD-2",
            "tiers": "1:24.50,10:22.00", "csrf_token": token,
        },
        follow_redirects=False,
    )
    assert r.status_code in (302, 303)


def test_create_coupon_rule(signed_in_client):
    token = get_csrf(signed_in_client.get("/rules").get_data(as_text=True))
    r = signed_in_client.post(
        "/rules",
        data={"rule_id": "c-new", "kind": "coupon", "sku": "", "code": "SAVE5", "amount": "5.00", "csrf_token": token},
        follow_redirects=False,
    )
    assert r.status_code in (302, 303)


def test_create_rule_duplicate_id_200(signed_in_client):
    token = get_csrf(signed_in_client.get("/rules").get_data(as_text=True))
    r = signed_in_client.post(
        "/rules",
        data={"rule_id": "r-pct-all", "kind": "percentage", "sku": "", "percent": "1", "csrf_token": token},
    )
    assert r.status_code == 200


def test_delete_rule(signed_in_client):
    token = get_csrf(signed_in_client.get("/rules").get_data(as_text=True))
    r = signed_in_client.post("/rules/r-pct-all/delete", data={"csrf_token": token}, follow_redirects=False)
    assert r.status_code in (302, 303)
    assert "r-pct-all" not in signed_in_client.get("/rules").get_data(as_text=True)


def test_delete_unknown_rule_404(signed_in_client):
    token = get_csrf(signed_in_client.get("/rules").get_data(as_text=True))
    r = signed_in_client.post("/rules/nope/delete", data={"csrf_token": token})
    assert r.status_code == 404


# --- jurisdictions ---------------------------------------------------------


def test_jurisdictions_list_shows_seed(signed_in_client):
    r = signed_in_client.get("/jurisdictions")
    assert r.status_code == 200
    body = r.get_data(as_text=True)
    assert "DE" in body and "IE" in body


def test_create_jurisdiction(signed_in_client):
    token = get_csrf(signed_in_client.get("/jurisdictions").get_data(as_text=True))
    r = signed_in_client.post(
        "/jurisdictions",
        data={"code": "FR", "name": "France", "default_rate": "0.20", "rates": "standard=0.20,reduced=0.055", "csrf_token": token},
        follow_redirects=False,
    )
    assert r.status_code in (302, 303)
    assert "FR" in signed_in_client.get("/jurisdictions").get_data(as_text=True)


def test_create_jurisdiction_duplicate_code_200(signed_in_client):
    token = get_csrf(signed_in_client.get("/jurisdictions").get_data(as_text=True))
    r = signed_in_client.post(
        "/jurisdictions",
        data={"code": "DE", "name": "dup", "default_rate": "0.19", "rates": "", "csrf_token": token},
    )
    assert r.status_code == 200


def test_delete_jurisdiction(signed_in_client):
    token = get_csrf(signed_in_client.get("/jurisdictions").get_data(as_text=True))
    r = signed_in_client.post("/jurisdictions/IE/delete", data={"csrf_token": token}, follow_redirects=False)
    assert r.status_code in (302, 303)


def test_delete_unknown_jurisdiction_404(signed_in_client):
    token = get_csrf(signed_in_client.get("/jurisdictions").get_data(as_text=True))
    r = signed_in_client.post("/jurisdictions/ZZ/delete", data={"csrf_token": token})
    assert r.status_code == 404


# --- customers ---------------------------------------------------------


def test_create_customer_and_view(signed_in_client):
    token = get_csrf(signed_in_client.get("/customers").get_data(as_text=True))
    r = signed_in_client.post(
        "/customers",
        data={"name": "Ada Example", "email": "ada@example.com", "address": "1 Sample Street\n10115 Berlin", "csrf_token": token},
        follow_redirects=False,
    )
    assert r.status_code in (302, 303)
    detail_url = r.headers["Location"]

    r = signed_in_client.get(detail_url)
    assert r.status_code == 200
    body = r.get_data(as_text=True)
    assert "Ada Example" in body
    assert "ada@example.com" in body


def test_create_customer_bad_email_200(signed_in_client):
    token = get_csrf(signed_in_client.get("/customers").get_data(as_text=True))
    r = signed_in_client.post(
        "/customers",
        data={"name": "Bad", "email": "not-an-email", "address": "x", "csrf_token": token},
    )
    assert r.status_code == 200
    assert "email" in r.get_data(as_text=True).lower()


def test_create_customer_duplicate_email_200(signed_in_client):
    token = get_csrf(signed_in_client.get("/customers").get_data(as_text=True))
    signed_in_client.post(
        "/customers",
        data={"name": "A", "email": "dup@example.com", "address": "x", "csrf_token": token},
    )
    token = get_csrf(signed_in_client.get("/customers").get_data(as_text=True))
    r = signed_in_client.post(
        "/customers",
        data={"name": "B", "email": "dup@example.com", "address": "y", "csrf_token": token},
    )
    assert r.status_code == 200
    assert "email" in r.get_data(as_text=True).lower()


def test_unknown_customer_404(signed_in_client):
    assert signed_in_client.get("/customers/99999").status_code == 404
    assert signed_in_client.get("/customers/99999/export.json").status_code == 404


def _create_customer(client, name="Ada Example", email="ada@example.com"):
    token = get_csrf(client.get("/customers").get_data(as_text=True))
    r = client.post(
        "/customers",
        data={"name": name, "email": email, "address": "1 Sample Street\n10115 Berlin", "csrf_token": token},
        follow_redirects=False,
    )
    return r.headers["Location"]


def test_customer_export_json_shape(signed_in_client):
    detail_url = _create_customer(signed_in_client)
    r = signed_in_client.get(detail_url + "/export.json")
    assert r.status_code == 200
    assert r.content_type == "application/json"
    payload = json.loads(r.get_data(as_text=True))
    assert list(payload.keys()) == ["customer_id", "name", "email", "address", "invoices"]
    assert payload["invoices"] == []


def test_customer_export_json_byte_stable(signed_in_client):
    detail_url = _create_customer(signed_in_client)
    body1 = signed_in_client.get(detail_url + "/export.json").get_data()
    body2 = signed_in_client.get(detail_url + "/export.json").get_data()
    assert body1 == body2


def _save_invoice(client, customer_id=""):
    token = get_csrf(client.get("/invoices/new").get_data(as_text=True))
    r = client.post(
        "/invoices",
        data={
            "jurisdiction": "DE", "currency": "EUR", "customer": customer_id,
            "sku": ["WID-1"], "quantity": ["1"], "coupon_codes": "", "csrf_token": token,
        },
        follow_redirects=False,
    )
    return r.headers["Location"]


def test_erase_customer(signed_in_client):
    detail_url = _create_customer(signed_in_client)
    customer_id = detail_url.rsplit("/", 1)[-1]
    invoice_url = _save_invoice(signed_in_client, customer_id=customer_id)

    token = get_csrf(signed_in_client.get(detail_url).get_data(as_text=True))
    r = signed_in_client.post(detail_url + "/erase", data={"csrf_token": token}, follow_redirects=False)
    assert r.status_code in (302, 303)
    assert r.headers["Location"].endswith("/customers")

    assert signed_in_client.get(detail_url).status_code == 404
    assert signed_in_client.get(detail_url + "/export.json").status_code == 404
    assert "Ada Example" not in signed_in_client.get("/customers").get_data(as_text=True)

    invoice_body = signed_in_client.get(invoice_url).get_data(as_text=True)
    assert "Ada Example" not in invoice_body
    assert "227.07" not in invoice_body  # sanity: not asserting exact figure here
    assert "erased" in invoice_body.lower()


def test_erase_unknown_customer_404(signed_in_client):
    token = get_csrf(signed_in_client.get("/customers").get_data(as_text=True))
    r = signed_in_client.post("/customers/99999/erase", data={"csrf_token": token})
    assert r.status_code == 404


# --- invoice builder / preview / save ---------------------------------------------------------


WORKED_EXAMPLE_FORM = {
    "jurisdiction": "DE",
    "currency": "EUR",
    "customer": "",
    "coupon_codes": "WELCOME",
    "sku": ["WID-1", "SEE-5", "BOK-3", "SRV-4"],
    "quantity": ["12", "7", "2", "1"],
}


def test_invoice_builder_page(signed_in_client):
    r = signed_in_client.get("/invoices/new")
    assert r.status_code == 200
    assert "DE" in r.get_data(as_text=True)


def test_preview_worked_example_full_page(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    data = dict(WORKED_EXAMPLE_FORM, csrf_token=token)
    r = signed_in_client.post("/invoices/preview", data=data)
    assert r.status_code == 200
    body = r.get_data(as_text=True)
    assert "227.07" in body
    assert "<html" in body.lower()


def test_preview_worked_example_fragment_matches_full_page_figures(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    data = dict(WORKED_EXAMPLE_FORM, csrf_token=token)
    r = signed_in_client.post("/invoices/preview", data=data, headers={"HX-Request": "true"})
    assert r.status_code == 200
    frag = r.get_data(as_text=True)
    assert "<html" not in frag.lower()
    for figure in ("228.35", "33.11", "195.24", "31.83", "227.07"):
        assert figure in frag


def test_preview_currency_defaults_to_eur(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    data = {
        "jurisdiction": "DE", "customer": "", "coupon_codes": "",
        "sku": ["WID-1"], "quantity": ["1"], "csrf_token": token,
    }
    r = signed_in_client.post("/invoices/preview", data=data)
    assert r.status_code == 200


def test_preview_no_lines_is_200_with_message(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    r = signed_in_client.post(
        "/invoices/preview",
        data={"jurisdiction": "DE", "currency": "EUR", "customer": "", "coupon_codes": "", "csrf_token": token},
    )
    assert r.status_code == 200


def test_preview_dropped_blank_pair(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    r = signed_in_client.post(
        "/invoices/preview",
        data={
            "jurisdiction": "DE", "currency": "EUR", "customer": "", "coupon_codes": "",
            "sku": ["WID-1", ""], "quantity": ["1", ""], "csrf_token": token,
        },
    )
    assert r.status_code == 200
    assert "10.00" in r.get_data(as_text=True)


def test_preview_half_filled_pair_names_empty_field(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    r = signed_in_client.post(
        "/invoices/preview",
        data={
            "jurisdiction": "DE", "currency": "EUR", "customer": "", "coupon_codes": "",
            "sku": ["", "WID-1"], "quantity": ["5", "1"], "csrf_token": token,
        },
    )
    assert r.status_code == 200
    assert "sku" in r.get_data(as_text=True).lower()


def test_preview_unknown_sku_400(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    r = signed_in_client.post(
        "/invoices/preview",
        data={
            "jurisdiction": "DE", "currency": "EUR", "customer": "", "coupon_codes": "",
            "sku": ["NOPE"], "quantity": ["1"], "csrf_token": token,
        },
    )
    assert r.status_code == 400


def test_preview_unknown_jurisdiction_400(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    r = signed_in_client.post(
        "/invoices/preview",
        data={
            "jurisdiction": "ZZ", "currency": "EUR", "customer": "", "coupon_codes": "",
            "sku": ["WID-1"], "quantity": ["1"], "csrf_token": token,
        },
    )
    assert r.status_code == 400


def test_preview_unknown_customer_400(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    r = signed_in_client.post(
        "/invoices/preview",
        data={
            "jurisdiction": "DE", "currency": "EUR", "customer": "99999", "coupon_codes": "",
            "sku": ["WID-1"], "quantity": ["1"], "csrf_token": token,
        },
    )
    assert r.status_code == 400


def test_preview_quantity_below_one_400(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    r = signed_in_client.post(
        "/invoices/preview",
        data={
            "jurisdiction": "DE", "currency": "EUR", "customer": "", "coupon_codes": "",
            "sku": ["WID-1"], "quantity": ["0"], "csrf_token": token,
        },
    )
    assert r.status_code == 400


def test_preview_unknown_coupon_code_is_200_validation_error(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    r = signed_in_client.post(
        "/invoices/preview",
        data={
            "jurisdiction": "DE", "currency": "EUR", "customer": "", "coupon_codes": "NOPE",
            "sku": ["WID-1"], "quantity": ["1"], "csrf_token": token,
        },
    )
    assert r.status_code == 200
    assert "coupon" in r.get_data(as_text=True).lower()


def test_preview_without_csrf_400(signed_in_client):
    r = signed_in_client.post(
        "/invoices/preview",
        data={
            "jurisdiction": "DE", "currency": "EUR", "customer": "", "coupon_codes": "",
            "sku": ["WID-1"], "quantity": ["1"],
        },
    )
    assert r.status_code in (400, 403)


def test_save_invoice_and_view(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    data = dict(WORKED_EXAMPLE_FORM, csrf_token=token)
    r = signed_in_client.post("/invoices", data=data, follow_redirects=False)
    assert r.status_code in (302, 303)
    invoice_url = r.headers["Location"]

    r = signed_in_client.get(invoice_url)
    assert r.status_code == 200
    assert "227.07" in r.get_data(as_text=True)


def test_save_invoice_no_lines_400(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    r = signed_in_client.post(
        "/invoices",
        data={"jurisdiction": "DE", "currency": "EUR", "customer": "", "coupon_codes": "", "csrf_token": token},
    )
    assert r.status_code == 400


def test_unknown_invoice_id_404(signed_in_client):
    assert signed_in_client.get("/invoices/99999").status_code == 404
    assert signed_in_client.get("/invoices/99999/export.json").status_code == 404
    assert signed_in_client.get("/invoices/99999/export.csv").status_code == 404
    assert signed_in_client.get("/invoices/99999/print").status_code == 404


def test_invoice_export_json_shape_and_byte_stability(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    data = dict(WORKED_EXAMPLE_FORM, csrf_token=token)
    r = signed_in_client.post("/invoices", data=data, follow_redirects=False)
    invoice_url = r.headers["Location"]

    r1 = signed_in_client.get(invoice_url + "/export.json")
    r2 = signed_in_client.get(invoice_url + "/export.json")
    assert r1.status_code == 200
    assert r1.content_type == "application/json"
    assert r1.get_data() == r2.get_data()

    payload = json.loads(r1.get_data(as_text=True))
    assert list(payload.keys()) == [
        "invoice_id", "currency", "jurisdiction", "lines",
        "subtotal", "discount_total", "taxable_total", "tax_total", "total", "applied",
    ]
    assert payload["subtotal"] == "228.35"
    assert payload["total"] == "227.07"
    line = payload["lines"][0]
    assert list(line.keys()) == [
        "sku", "name", "quantity", "unit_price", "gross", "line_discount",
        "net", "invoice_discount", "taxable", "tax", "total", "applied",
    ]


def test_invoice_export_json_has_no_customer_data(signed_in_client):
    detail_url = _create_customer(signed_in_client)
    customer_id = detail_url.rsplit("/", 1)[-1]
    invoice_url = _save_invoice(signed_in_client, customer_id=customer_id)
    body = signed_in_client.get(invoice_url + "/export.json").get_data(as_text=True)
    assert "Ada Example" not in body
    assert "ada@example.com" not in body


def test_invoice_export_csv_shape(signed_in_client):
    token = get_csrf(signed_in_client.get("/invoices/new").get_data(as_text=True))
    data = dict(WORKED_EXAMPLE_FORM, csrf_token=token)
    r = signed_in_client.post("/invoices", data=data, follow_redirects=False)
    invoice_url = r.headers["Location"]

    r = signed_in_client.get(invoice_url + "/export.csv")
    assert r.status_code == 200
    assert r.content_type == "text/csv; charset=utf-8"
    body = r.get_data(as_text=True)
    assert "\r\n" not in body
    lines = body.strip("\n").split("\n")
    assert lines[0] == "sku,name,quantity,unit_price,gross,line_discount,net,invoice_discount,taxable,tax,total"
    assert lines[-1].startswith("TOTAL,,,,")
    assert lines[-1].endswith("228.35,33.11,195.24,31.83,227.07")


def test_invoice_print_page_shows_customer(signed_in_client):
    detail_url = _create_customer(signed_in_client)
    customer_id = detail_url.rsplit("/", 1)[-1]
    invoice_url = _save_invoice(signed_in_client, customer_id=customer_id)
    r = signed_in_client.get(invoice_url + "/print")
    assert r.status_code == 200
    assert "Ada Example" in r.get_data(as_text=True)
