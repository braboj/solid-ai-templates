# tariff

A pricing and invoicing engine, plus a server-rendered web application for
maintaining the catalogue, discount rules, jurisdictions and customers, and
building invoices.

## Install

```
python -m venv .venv
.venv/Scripts/activate        # or: source .venv/bin/activate
pip install .
```

`import tariff` then works without Flask installed and without touching a
database — the pricing engine has no dependency on the web application.

## Seed the database

The web app needs a SQLite file seeded with the fixture described in
`SPEC.md` section 8 (five products, two jurisdictions, six discount rules,
and one administrator account). Seeding requires the administrator's
password in the environment:

```
export TARIFF_ADMIN_PASSWORD=choose-a-password   # PowerShell: $env:TARIFF_ADMIN_PASSWORD='...'
tariff seed --db tariff.db
```

Running `tariff seed` again resets the database back to the fixture
(including removing any customers or invoices created since).

## Run

```
tariff serve --db tariff.db --port 5000
```

Open `http://127.0.0.1:5000/`, sign in as `admin` with the password you
seeded with, and use the dashboard to reach products, rules, jurisdictions,
customers and the invoice builder.

## Run the tests

```
pip install ".[test]"
pytest
```

## Notes

- Money is `decimal.Decimal` throughout the pricing path; rounding is
  half-even to two decimal places and happens only where `SPEC.md` section 4
  specifies.
- The invoice builder's fields keep working with JavaScript disabled; HTMX
  (vendored at `tariff/web/static/htmx.min.js`) only adds live re-pricing on
  top.
- Every POST route requires a CSRF token, which the templates embed
  automatically.
