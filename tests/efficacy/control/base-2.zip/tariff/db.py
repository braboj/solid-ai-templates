"""SQLite persistence for the web application.

This module knows nothing about Flask; it is plain sqlite3 plus
conversions to and from the ``tariff`` domain objects. The web layer owns
connection lifecycle (one connection per request).
"""

import json
import sqlite3
from decimal import Decimal

from .models import Jurisdiction, Product
from .rules import BulkRule, CouponRule, PercentageRule, TieredRule

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    sku TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    unit_price TEXT NOT NULL,
    tax_category TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS jurisdictions (
    code TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    default_rate TEXT NOT NULL,
    rates TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rules (
    rule_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    sku TEXT,
    data TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS customers (
    customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    address TEXT,
    erased INTEGER NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_email
    ON customers(email) WHERE erased = 0;

CREATE TABLE IF NOT EXISTS invoices (
    invoice_id INTEGER PRIMARY KEY AUTOINCREMENT,
    currency TEXT NOT NULL,
    jurisdiction_code TEXT NOT NULL,
    jurisdiction_name TEXT NOT NULL,
    customer_id INTEGER,
    coupon_codes TEXT NOT NULL,
    applied TEXT NOT NULL,
    subtotal TEXT NOT NULL,
    discount_total TEXT NOT NULL,
    taxable_total TEXT NOT NULL,
    tax_total TEXT NOT NULL,
    total TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS invoice_lines (
    invoice_id INTEGER NOT NULL,
    line_order INTEGER NOT NULL,
    sku TEXT NOT NULL,
    name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price TEXT NOT NULL,
    gross TEXT NOT NULL,
    line_discount TEXT NOT NULL,
    net TEXT NOT NULL,
    invoice_discount TEXT NOT NULL,
    taxable TEXT NOT NULL,
    tax TEXT NOT NULL,
    total TEXT NOT NULL,
    applied TEXT NOT NULL,
    PRIMARY KEY (invoice_id, line_order)
);
"""


def connect(db_path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    init_schema(conn)
    return conn


def init_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


# --- products ---------------------------------------------------------


def _row_to_product(row):
    return Product(row["sku"], row["name"], row["unit_price"], row["tax_category"])


def list_products(conn):
    rows = conn.execute("SELECT * FROM products ORDER BY sku").fetchall()
    return [_row_to_product(row) for row in rows]


def get_product(conn, sku):
    row = conn.execute("SELECT * FROM products WHERE sku = ?", (sku,)).fetchone()
    return _row_to_product(row) if row else None


def add_product(conn, product):
    conn.execute(
        "INSERT INTO products (sku, name, unit_price, tax_category) VALUES (?, ?, ?, ?)",
        (product.sku, product.name, str(product.unit_price), product.tax_category),
    )
    conn.commit()


def delete_product(conn, sku):
    cur = conn.execute("DELETE FROM products WHERE sku = ?", (sku,))
    conn.commit()
    return cur.rowcount > 0


# --- rules --------------------------------------------------------------


def _rule_to_storage(rule):
    if isinstance(rule, PercentageRule):
        data = {"percent": str(rule.percent)}
    elif isinstance(rule, BulkRule):
        data = {"buy": rule.buy, "pay": rule.pay}
    elif isinstance(rule, TieredRule):
        data = {"tiers": [[mq, str(up)] for mq, up in rule.tiers]}
    elif isinstance(rule, CouponRule):
        data = {
            "code": rule.code,
            "percent": str(rule.percent) if rule.percent is not None else None,
            "amount": str(rule.amount) if rule.amount is not None else None,
        }
    else:
        raise TypeError(f"unknown rule type: {type(rule)!r}")
    return rule.KIND, rule.sku if hasattr(rule, "sku") else None, json.dumps(data)


def _row_to_rule(row):
    kind = row["kind"]
    data = json.loads(row["data"])
    rule_id = row["rule_id"]
    sku = row["sku"]
    if kind == "percentage":
        return PercentageRule(rule_id, data["percent"], sku=sku)
    if kind == "bulk":
        return BulkRule(rule_id, sku, data["buy"], data["pay"])
    if kind == "tiered":
        return TieredRule(rule_id, sku, [(mq, up) for mq, up in data["tiers"]])
    if kind == "coupon":
        return CouponRule(rule_id, data["code"], percent=data["percent"], amount=data["amount"])
    raise ValueError(f"unknown rule kind in database: {kind}")


def list_rules(conn):
    rows = conn.execute("SELECT * FROM rules ORDER BY rule_id").fetchall()
    return [_row_to_rule(row) for row in rows]


def get_rule(conn, rule_id):
    row = conn.execute("SELECT * FROM rules WHERE rule_id = ?", (rule_id,)).fetchone()
    return _row_to_rule(row) if row else None


def add_rule(conn, rule):
    kind, sku, data = _rule_to_storage(rule)
    conn.execute(
        "INSERT INTO rules (rule_id, kind, sku, data) VALUES (?, ?, ?, ?)",
        (rule.rule_id, kind, sku, data),
    )
    conn.commit()


def delete_rule(conn, rule_id):
    cur = conn.execute("DELETE FROM rules WHERE rule_id = ?", (rule_id,))
    conn.commit()
    return cur.rowcount > 0


# --- jurisdictions --------------------------------------------------------


def _row_to_jurisdiction(row):
    rates = json.loads(row["rates"])
    return Jurisdiction(row["code"], row["name"], rates, row["default_rate"])


def list_jurisdictions(conn):
    rows = conn.execute("SELECT * FROM jurisdictions ORDER BY code").fetchall()
    return [_row_to_jurisdiction(row) for row in rows]


def get_jurisdiction(conn, code):
    row = conn.execute("SELECT * FROM jurisdictions WHERE code = ?", (code,)).fetchone()
    return _row_to_jurisdiction(row) if row else None


def add_jurisdiction(conn, jurisdiction):
    rates = {category: str(rate) for category, rate in jurisdiction.rates.items()}
    conn.execute(
        "INSERT INTO jurisdictions (code, name, default_rate, rates) VALUES (?, ?, ?, ?)",
        (
            jurisdiction.code,
            jurisdiction.name,
            str(jurisdiction.default_rate),
            json.dumps(rates),
        ),
    )
    conn.commit()


def delete_jurisdiction(conn, code):
    cur = conn.execute("DELETE FROM jurisdictions WHERE code = ?", (code,))
    conn.commit()
    return cur.rowcount > 0


# --- customers --------------------------------------------------------------


def list_customers(conn):
    rows = conn.execute(
        "SELECT * FROM customers WHERE erased = 0 ORDER BY customer_id"
    ).fetchall()
    return [dict(row) for row in rows]


def get_customer(conn, customer_id):
    row = conn.execute(
        "SELECT * FROM customers WHERE customer_id = ?", (customer_id,)
    ).fetchone()
    return dict(row) if row else None


def email_taken(conn, email):
    row = conn.execute(
        "SELECT 1 FROM customers WHERE erased = 0 AND email = ?", (email,)
    ).fetchone()
    return row is not None


def add_customer(conn, name, email, address):
    cur = conn.execute(
        "INSERT INTO customers (name, email, address, erased) VALUES (?, ?, ?, 0)",
        (name, email, address),
    )
    conn.commit()
    return cur.lastrowid


def erase_customer(conn, customer_id):
    cur = conn.execute(
        "UPDATE customers SET erased = 1, name = NULL, email = NULL, address = NULL "
        "WHERE customer_id = ? AND erased = 0",
        (customer_id,),
    )
    conn.commit()
    return cur.rowcount > 0


def customer_invoice_ids(conn, customer_id):
    rows = conn.execute(
        "SELECT invoice_id FROM invoices WHERE customer_id = ? ORDER BY invoice_id",
        (customer_id,),
    ).fetchall()
    return [row["invoice_id"] for row in rows]


# --- invoices --------------------------------------------------------------


def add_invoice(conn, *, currency, jurisdiction_code, jurisdiction_name, customer_id,
                 coupon_codes, applied, subtotal, discount_total, taxable_total,
                 tax_total, total, lines, created_at):
    cur = conn.execute(
        "INSERT INTO invoices (currency, jurisdiction_code, jurisdiction_name, "
        "customer_id, coupon_codes, applied, subtotal, discount_total, "
        "taxable_total, tax_total, total, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            currency,
            jurisdiction_code,
            jurisdiction_name,
            customer_id,
            json.dumps(list(coupon_codes)),
            json.dumps(list(applied)),
            str(subtotal),
            str(discount_total),
            str(taxable_total),
            str(tax_total),
            str(total),
            created_at,
        ),
    )
    invoice_id = cur.lastrowid
    for order, line in enumerate(lines):
        conn.execute(
            "INSERT INTO invoice_lines (invoice_id, line_order, sku, name, quantity, "
            "unit_price, gross, line_discount, net, invoice_discount, taxable, tax, "
            "total, applied) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                invoice_id,
                order,
                line["sku"],
                line["name"],
                line["quantity"],
                str(line["unit_price"]),
                str(line["gross"]),
                str(line["line_discount"]),
                str(line["net"]),
                str(line["invoice_discount"]),
                str(line["taxable"]),
                str(line["tax"]),
                str(line["total"]),
                json.dumps(list(line["applied"])),
            ),
        )
    conn.commit()
    return invoice_id


def get_invoice(conn, invoice_id):
    row = conn.execute(
        "SELECT * FROM invoices WHERE invoice_id = ?", (invoice_id,)
    ).fetchone()
    if row is None:
        return None
    invoice = dict(row)
    invoice["coupon_codes"] = json.loads(invoice["coupon_codes"])
    invoice["applied"] = json.loads(invoice["applied"])
    line_rows = conn.execute(
        "SELECT * FROM invoice_lines WHERE invoice_id = ? ORDER BY line_order",
        (invoice_id,),
    ).fetchall()
    lines = []
    for line_row in line_rows:
        line = dict(line_row)
        line["applied"] = json.loads(line["applied"])
        lines.append(line)
    invoice["lines"] = lines
    return invoice


# --- users --------------------------------------------------------------


def get_user(conn, username):
    row = conn.execute(
        "SELECT * FROM users WHERE username = ?", (username,)
    ).fetchone()
    return dict(row) if row else None


def set_user_password(conn, username, password_hash):
    conn.execute(
        "INSERT INTO users (username, password_hash) VALUES (?, ?) "
        "ON CONFLICT(username) DO UPDATE SET password_hash = excluded.password_hash",
        (username, password_hash),
    )
    conn.commit()


# --- seeding --------------------------------------------------------------

SEED_PRODUCTS = [
    ("WID-1", "Widget", "10.00", "standard"),
    ("GAD-2", "Gadget", "24.50", "standard"),
    ("BOK-3", "Handbook", "12.00", "reduced"),
    ("SRV-4", "Support hour", "80.00", "standard"),
    ("SEE-5", "Seed pack", "3.75", "zero"),
]

SEED_JURISDICTIONS = [
    ("DE", "Germany", {"standard": "0.19", "reduced": "0.07", "zero": "0.00"}, "0.19"),
    ("IE", "Ireland", {"standard": "0.23", "reduced": "0.135", "zero": "0.00"}, "0.23"),
]


def _seed_rules():
    return [
        TieredRule("r-tier-wid", "WID-1", [(1, "10.00"), (10, "9.00"), (50, "8.00")]),
        BulkRule("r-bulk-see", "SEE-5", 3, 2),
        PercentageRule("r-pct-bok", "10", sku="BOK-3"),
        PercentageRule("r-pct-all", "5"),
        CouponRule("c-welcome", "WELCOME", percent="10"),
        CouponRule("c-tenoff", "TENOFF", amount="10.00"),
    ]


def seed(conn, admin_password):
    """Reset the database to the fixture described in SPEC.md section 8."""
    if not admin_password:
        raise ValueError("TARIFF_ADMIN_PASSWORD must be set and non-empty to seed")

    from werkzeug.security import generate_password_hash

    conn.execute("DELETE FROM invoice_lines")
    conn.execute("DELETE FROM invoices")
    conn.execute("DELETE FROM customers")
    conn.execute("DELETE FROM rules")
    conn.execute("DELETE FROM jurisdictions")
    conn.execute("DELETE FROM products")
    conn.execute("DELETE FROM users")
    if conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'sqlite_sequence'"
    ).fetchone():
        conn.execute(
            "DELETE FROM sqlite_sequence WHERE name IN ('customers', 'invoices')"
        )
    conn.commit()

    for sku, name, unit_price, tax_category in SEED_PRODUCTS:
        add_product(conn, Product(sku, name, unit_price, tax_category))

    for code, name, rates, default_rate in SEED_JURISDICTIONS:
        add_jurisdiction(conn, Jurisdiction(code, name, rates, default_rate))

    for rule in _seed_rules():
        add_rule(conn, rule)

    set_user_password(conn, "admin", generate_password_hash(admin_password))
