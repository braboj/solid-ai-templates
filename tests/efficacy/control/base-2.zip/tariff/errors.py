"""Exceptions raised on purpose by the tariff package."""


class TariffError(Exception):
    """Base of every exception this package raises on purpose."""


class ValidationError(TariffError):
    """Raised when a domain object is constructed with bad data.

    ``field`` names the offending field, when there is a single one to
    name, so the web layer can attach the message to the right form field.
    """

    def __init__(self, message, field=None):
        super().__init__(message)
        self.field = field


class UnknownSkuError(TariffError):
    """Raised by :meth:`tariff.Catalog.get` for an unknown sku."""

    def __init__(self, sku):
        super().__init__(f"unknown sku: {sku}")
        self.sku = sku


class PricingError(TariffError):
    """Raised by :func:`tariff.price` when it refuses to price an invoice."""
