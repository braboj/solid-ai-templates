"""Command-line entry points: ``tariff seed`` and ``tariff serve``.

Importing this module touches Flask (for ``serve``) and the database, so
it is kept out of ``tariff/__init__.py``.
"""

import argparse
import os
import sys


def _cmd_seed(args):
    from . import db

    password = os.environ.get("TARIFF_ADMIN_PASSWORD", "")
    if not password:
        print(
            "TARIFF_ADMIN_PASSWORD must be set and non-empty to seed.",
            file=sys.stderr,
        )
        return 1
    conn = db.connect(args.db)
    try:
        db.seed(conn, password)
    finally:
        conn.close()
    print(f"Seeded {args.db}")
    return 0


def _cmd_serve(args):
    from . import create_app

    app = create_app(args.db)
    app.run(host=args.host, port=args.port, debug=args.debug)
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(prog="tariff")
    subparsers = parser.add_subparsers(dest="command", required=True)

    seed_parser = subparsers.add_parser(
        "seed", help="reset the database to the seed fixture"
    )
    seed_parser.add_argument("--db", default="tariff.db", help="path to the SQLite file")
    seed_parser.set_defaults(func=_cmd_seed)

    serve_parser = subparsers.add_parser("serve", help="run the development server")
    serve_parser.add_argument("--db", default="tariff.db", help="path to the SQLite file")
    serve_parser.add_argument("--host", default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=5000)
    serve_parser.add_argument("--debug", action="store_true")
    serve_parser.set_defaults(func=_cmd_serve)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
