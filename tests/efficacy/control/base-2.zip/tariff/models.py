"""Products, catalogues, jurisdictions and invoices."""

from dataclasses import dataclass, field
from typing import Dict, Iterator, Optional, Sequence, Tuple

from ._decimal import to_decimal
from .errors import UnknownSkuError, ValidationError


@dataclass(frozen=True)
class Product:
    sku: str
    name: str
    unit_price: object
    tax_category: str

    def __post_init__(self):
        if not self.sku:
            raise ValidationError("sku must not be empty", field="sku")
        if not self.name:
            raise ValidationError("name must not be empty", field="name")
        price = to_decimal(self.unit_price, field="unit_price")
        if price < 0:
            raise ValidationError("unit_price must be at least zero", field="unit_price")
        object.__setattr__(self, "unit_price", price)
        if not self.tax_category:
            raise ValidationError("tax_category must not be empty", field="tax_category")


class Catalog:
    """An addressable set of products, keyed by sku."""

    def __init__(self, products: Sequence[Product] = ()):
        self._products: Dict[str, Product] = {}
        for product in products:
            self.add(product)

    def add(self, product: Product) -> None:
        if product.sku in self._products:
            raise ValidationError(f"duplicate sku: {product.sku}", field="sku")
        self._products[product.sku] = product

    def get(self, sku: str) -> Product:
        try:
            return self._products[sku]
        except KeyError:
            raise UnknownSkuError(sku) from None

    def __iter__(self) -> Iterator[Product]:
        return iter(self._products.values())

    def __len__(self) -> int:
        return len(self._products)

    def __contains__(self, sku: str) -> bool:
        return sku in self._products


@dataclass(frozen=True)
class InvoiceLine:
    product: Product
    quantity: int


@dataclass(frozen=True)
class Invoice:
    currency: str
    lines: Sequence[InvoiceLine]
    coupon_codes: Sequence[str] = ()

    def __post_init__(self):
        if not self.currency:
            raise ValidationError("currency must not be empty", field="currency")
        object.__setattr__(self, "lines", tuple(self.lines))
        object.__setattr__(self, "coupon_codes", tuple(self.coupon_codes))


@dataclass(frozen=True)
class Jurisdiction:
    code: str
    name: str
    rates: Dict[str, object]
    default_rate: object

    def __post_init__(self):
        if not self.code:
            raise ValidationError("code must not be empty", field="code")
        if not self.name:
            raise ValidationError("name must not be empty", field="name")
        rates = {
            category: to_decimal(rate, field="rates")
            for category, rate in dict(self.rates).items()
        }
        object.__setattr__(self, "rates", rates)
        object.__setattr__(
            self, "default_rate", to_decimal(self.default_rate, field="default_rate")
        )
