"""Discount rules: percentage, bulk, tiered and coupon."""

from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

from ._decimal import to_decimal
from .errors import ValidationError


@dataclass(frozen=True)
class PercentageRule:
    rule_id: str
    percent: object
    sku: Optional[str] = None

    KIND = "percentage"

    def __post_init__(self):
        percent = to_decimal(self.percent, field="percent")
        if not (percent > 0 and percent <= 100):
            raise ValidationError(
                "percent must be greater than zero and at most 100", field="percent"
            )
        object.__setattr__(self, "percent", percent)


@dataclass(frozen=True)
class BulkRule:
    rule_id: str
    sku: str
    buy: int
    pay: int

    KIND = "bulk"

    def __post_init__(self):
        if self.pay < 1:
            raise ValidationError("pay must be at least one", field="pay")
        if not (self.buy > self.pay):
            raise ValidationError("buy must be greater than pay", field="buy")


@dataclass(frozen=True)
class TieredRule:
    rule_id: str
    sku: str
    tiers: Sequence[Tuple[object, object]]

    KIND = "tiered"

    def __post_init__(self):
        tiers = tuple(
            (int(min_quantity), to_decimal(unit_price, field="tiers"))
            for min_quantity, unit_price in self.tiers
        )
        if not tiers:
            raise ValidationError("tiers must not be empty", field="tiers")
        previous = None
        for min_quantity, unit_price in tiers:
            if min_quantity < 1:
                raise ValidationError(
                    "tier min_quantity must be at least one", field="tiers"
                )
            if unit_price < 0:
                raise ValidationError(
                    "tier unit_price must not be negative", field="tiers"
                )
            if previous is not None and min_quantity <= previous:
                raise ValidationError(
                    "tiers must be strictly increasing by min_quantity", field="tiers"
                )
            previous = min_quantity
        object.__setattr__(self, "tiers", tiers)


@dataclass(frozen=True)
class CouponRule:
    rule_id: str
    code: str
    percent: Optional[object] = None
    amount: Optional[object] = None

    KIND = "coupon"

    def __post_init__(self):
        if not self.code:
            raise ValidationError("code must not be empty", field="code")
        has_percent = self.percent is not None
        has_amount = self.amount is not None
        if has_percent == has_amount:
            raise ValidationError(
                "coupon must carry exactly one of percent or amount", field="percent"
            )
        if has_percent:
            object.__setattr__(
                self, "percent", to_decimal(self.percent, field="percent")
            )
        if has_amount:
            amount = to_decimal(self.amount, field="amount")
            if not (amount > 0):
                raise ValidationError("amount must be greater than zero", field="amount")
            object.__setattr__(self, "amount", amount)
