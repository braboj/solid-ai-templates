from flask import abort, redirect, render_template, request, url_for

from . import get_conn
from .. import db as db_module
from ..errors import ValidationError
from ..rules import BulkRule, CouponRule, PercentageRule, TieredRule
from .helpers import field, parse_decimal, parse_int, parse_tiers, require

KINDS = ("percentage", "bulk", "tiered", "coupon")


def _render(conn, *, message=None, error_field=None, form=None, status=200):
    rules = db_module.list_rules(conn)
    return (
        render_template(
            "rules.html",
            rules=rules,
            message=message,
            error_field=error_field,
            form=form or {},
        ),
        status,
    )


def _build_rule(conn, form):
    rule_id = require(form, "rule_id")
    if db_module.get_rule(conn, rule_id) is not None:
        raise ValidationError("rule_id already exists", field="rule_id")

    kind = require(form, "kind")
    if kind not in KINDS:
        raise ValidationError("kind must be one of percentage, bulk, tiered, coupon", field="kind")

    sku = field(form, "sku") or None

    if kind == "percentage":
        percent = parse_decimal(form, "percent")
        return PercentageRule(rule_id, percent, sku=sku)

    if kind == "bulk":
        if not sku:
            raise ValidationError("sku is required for a bulk rule", field="sku")
        buy = parse_int(form, "buy")
        pay = parse_int(form, "pay")
        return BulkRule(rule_id, sku, buy, pay)

    if kind == "tiered":
        if not sku:
            raise ValidationError("sku is required for a tiered rule", field="sku")
        tiers_raw = require(form, "tiers")
        tiers = parse_tiers(tiers_raw)
        return TieredRule(rule_id, sku, tiers)

    # coupon
    if sku:
        raise ValidationError("a coupon rule is always invoice-scoped", field="sku")
    code = require(form, "code")
    percent_raw = field(form, "percent")
    amount_raw = field(form, "amount")
    percent = parse_decimal(form, "percent", required=False) if percent_raw else None
    amount = parse_decimal(form, "amount", required=False) if amount_raw else None
    return CouponRule(rule_id, code, percent=percent, amount=amount)


def register(app):
    @app.route("/rules", methods=["GET"])
    def rules():
        conn = get_conn()
        return _render(conn)

    @app.route("/rules", methods=["POST"])
    def create_rule():
        conn = get_conn()
        form = request.form
        try:
            rule = _build_rule(conn, form)
        except ValidationError as exc:
            return _render(conn, message=str(exc), error_field=exc.field, form=form)

        db_module.add_rule(conn, rule)
        return redirect(url_for("rules"))

    @app.route("/rules/<rule_id>/delete", methods=["POST"])
    def delete_rule(rule_id):
        conn = get_conn()
        if db_module.get_rule(conn, rule_id) is None:
            abort(404)
        db_module.delete_rule(conn, rule_id)
        return redirect(url_for("rules"))
