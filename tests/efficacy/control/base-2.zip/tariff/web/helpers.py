"""Shared helpers for the web views: form parsing and small utilities."""

from decimal import Decimal, InvalidOperation

from ..errors import ValidationError


def field(form, name):
    """Return a form field's value, stripped, defaulting to ''."""
    return (form.get(name) or "").strip()


def require(form, name, label=None):
    value = field(form, name)
    if not value:
        raise ValidationError(f"{label or name} is required", field=name)
    return value


def parse_decimal(form, name, label=None, required=True):
    raw = field(form, name)
    if not raw:
        if required:
            raise ValidationError(f"{label or name} is required", field=name)
        return None
    try:
        return Decimal(raw)
    except InvalidOperation:
        raise ValidationError(f"{label or name} must be a number", field=name) from None


def parse_int(form, name, label=None, required=True):
    raw = field(form, name)
    if not raw:
        if required:
            raise ValidationError(f"{label or name} is required", field=name)
        return None
    try:
        return int(raw)
    except ValueError:
        raise ValidationError(f"{label or name} must be a whole number", field=name) from None


def parse_tiers(raw):
    """Parse ``1:10.00,10:9.00,50:8.00`` into a list of (int, Decimal)."""
    tiers = []
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if ":" not in chunk:
            raise ValidationError("tiers must be min_quantity:unit_price pairs", field="tiers")
        min_q, unit_price = chunk.split(":", 1)
        try:
            tiers.append((int(min_q.strip()), Decimal(unit_price.strip())))
        except InvalidOperation:
            raise ValidationError("tiers must be min_quantity:unit_price pairs", field="tiers") from None
        except ValueError:
            raise ValidationError("tiers must be min_quantity:unit_price pairs", field="tiers") from None
    return tiers


def parse_rates(raw):
    """Parse ``standard=0.19,reduced=0.07`` into a dict."""
    rates = {}
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "=" not in chunk:
            raise ValidationError("rates must be category=rate pairs", field="rates")
        category, rate = chunk.split("=", 1)
        category = category.strip()
        try:
            rates[category] = Decimal(rate.strip())
        except InvalidOperation:
            raise ValidationError("rates must be category=rate pairs", field="rates") from None
    return rates


def parse_codes(raw):
    """Parse ``WELCOME, TENOFF`` into a list of stripped, non-empty codes."""
    return [chunk.strip() for chunk in raw.split(",") if chunk.strip()]


def money(value):
    """Format a Decimal as a string with exactly two decimals."""
    return f"{value:.2f}"
