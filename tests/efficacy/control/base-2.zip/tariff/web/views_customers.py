import json

from flask import Response, abort, redirect, render_template, request, url_for

from . import get_conn
from .. import db as db_module
from ..errors import ValidationError
from .helpers import require


def _render_list(conn, *, message=None, error_field=None, form=None, status=200):
    customers = db_module.list_customers(conn)
    return (
        render_template(
            "customers.html",
            customers=customers,
            message=message,
            error_field=error_field,
            form=form or {},
        ),
        status,
    )


def _validate_email(email):
    if email.count("@") != 1:
        raise ValidationError("email must contain exactly one @", field="email")


def register(app):
    @app.route("/customers", methods=["GET"])
    def customers():
        conn = get_conn()
        return _render_list(conn)

    @app.route("/customers", methods=["POST"])
    def create_customer():
        conn = get_conn()
        form = request.form
        try:
            name = require(form, "name")
            email = require(form, "email")
            _validate_email(email)
            address = require(form, "address")
            if db_module.email_taken(conn, email):
                raise ValidationError("email already in use", field="email")
        except ValidationError as exc:
            return _render_list(conn, message=str(exc), error_field=exc.field, form=form)

        customer_id = db_module.add_customer(conn, name, email, address)
        return redirect(url_for("customer_detail", customer_id=customer_id))

    @app.route("/customers/<int:customer_id>", methods=["GET"])
    def customer_detail(customer_id):
        conn = get_conn()
        customer = db_module.get_customer(conn, customer_id)
        if customer is None or customer["erased"]:
            abort(404)
        invoice_ids = db_module.customer_invoice_ids(conn, customer_id)
        return render_template("customer_detail.html", customer=customer, invoice_ids=invoice_ids)

    @app.route("/customers/<int:customer_id>/erase", methods=["POST"])
    def erase_customer(customer_id):
        conn = get_conn()
        customer = db_module.get_customer(conn, customer_id)
        if customer is None or customer["erased"]:
            abort(404)
        db_module.erase_customer(conn, customer_id)
        return redirect(url_for("customers"))

    @app.route("/customers/<int:customer_id>/export.json", methods=["GET"])
    def customer_export_json(customer_id):
        conn = get_conn()
        customer = db_module.get_customer(conn, customer_id)
        if customer is None or customer["erased"]:
            abort(404)
        invoice_ids = db_module.customer_invoice_ids(conn, customer_id)
        payload = {
            "customer_id": customer["customer_id"],
            "name": customer["name"],
            "email": customer["email"],
            "address": customer["address"],
            "invoices": invoice_ids,
        }
        body = json.dumps(payload)
        return Response(body, mimetype="application/json")
