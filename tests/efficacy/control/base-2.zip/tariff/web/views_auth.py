from flask import redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash

from . import get_conn
from .. import db as db_module


def register(app):
    @app.route("/sign-in", methods=["GET"])
    def sign_in():
        next_url = request.args.get("next", "")
        return render_template("sign_in.html", next=next_url, message=None, username=None)

    @app.route("/sign-in", methods=["POST"])
    def sign_in_post():
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        next_url = request.form.get("next") or ""

        conn = get_conn()
        user = db_module.get_user(conn, username)
        if user is None or not check_password_hash(user["password_hash"], password):
            return (
                render_template(
                    "sign_in.html",
                    next=next_url,
                    message="Wrong username or password.",
                    username=username,
                ),
                200,
            )

        session["signed_in"] = True
        session["username"] = username
        if not next_url.startswith("/") or next_url.startswith("//"):
            next_url = url_for("dashboard")
        return redirect(next_url)

    @app.route("/sign-out", methods=["POST"])
    def sign_out():
        session.clear()
        return redirect(url_for("sign_in"))
