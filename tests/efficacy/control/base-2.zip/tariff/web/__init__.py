"""The Flask application factory. Importing this module loads Flask."""

import hmac
import os
import secrets

from flask import Flask, current_app, g, redirect, request, session, url_for

from .. import db as db_module

EXEMPT_PATHS = {"/sign-in"}


def _get_or_create_secret_key(db_path):
    key_path = f"{db_path}.secretkey"
    if os.path.exists(key_path):
        with open(key_path, "rb") as handle:
            return handle.read()
    key = secrets.token_bytes(32)
    with open(key_path, "wb") as handle:
        handle.write(key)
    return key


def get_conn():
    if "conn" not in g:
        g.conn = db_module.connect(current_app.config["TARIFF_DB_PATH"])
    return g.conn


def get_csrf_token():
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


def _csrf_valid():
    token = session.get("csrf_token")
    submitted = request.form.get("csrf_token")
    return bool(token) and bool(submitted) and hmac.compare_digest(token, submitted)


def is_signed_in():
    return bool(session.get("signed_in"))


def create_app(db_path):
    app = Flask(__name__)
    app.config["TARIFF_DB_PATH"] = db_path
    app.secret_key = _get_or_create_secret_key(db_path)

    app.jinja_env.globals["csrf_token"] = get_csrf_token
    app.jinja_env.globals["is_signed_in"] = is_signed_in

    @app.teardown_appcontext
    def _close_conn(exc):
        conn = g.pop("conn", None)
        if conn is not None:
            conn.close()

    @app.before_request
    def _security_gate():
        if request.endpoint == "static":
            return None
        if request.path not in EXEMPT_PATHS:
            if not is_signed_in():
                if request.method == "GET":
                    if request.query_string:
                        next_url = request.full_path
                    else:
                        next_url = request.path
                    return redirect(url_for("sign_in", next=next_url))
                return redirect(url_for("sign_in"))
        if request.method == "POST":
            if not _csrf_valid():
                from flask import abort

                abort(400)
        return None

    from . import (
        views_auth,
        views_customers,
        views_invoices,
        views_jurisdictions,
        views_main,
        views_products,
        views_rules,
    )

    views_main.register(app)
    views_auth.register(app)
    views_products.register(app)
    views_rules.register(app)
    views_jurisdictions.register(app)
    views_customers.register(app)
    views_invoices.register(app)

    return app
