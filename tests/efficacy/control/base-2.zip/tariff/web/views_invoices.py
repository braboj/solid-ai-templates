import csv
import io
import json
from decimal import Decimal
from itertools import zip_longest

from flask import Response, abort, redirect, render_template, request, url_for

from . import get_conn
from .. import db as db_module
from ..errors import PricingError, ValidationError
from ..models import Invoice, InvoiceLine
from ..pricing import price
from .helpers import field, money
from .pricing_view import view_from_priced, view_from_stored

BLANK_ROWS = 12


def _parse_lines(conn, form):
    """Parse sku/quantity pairs. Aborts 400 for unknown sku or bad quantity."""
    skus = form.getlist("sku")
    quantities = form.getlist("quantity")
    raw_pairs = []
    lines = []
    for sku_raw, qty_raw in zip_longest(skus, quantities, fillvalue=""):
        sku_raw = (sku_raw or "").strip()
        qty_raw = (qty_raw or "").strip()
        raw_pairs.append((sku_raw, qty_raw))
        if not sku_raw and not qty_raw:
            continue
        if not sku_raw:
            raise ValidationError("sku is required", field="sku")
        if not qty_raw:
            raise ValidationError("quantity is required", field="quantity")
        product = db_module.get_product(conn, sku_raw)
        if product is None:
            abort(400)
        try:
            quantity = int(qty_raw)
        except ValueError:
            abort(400)
        if quantity < 1:
            abort(400)
        lines.append(InvoiceLine(product, quantity))
    return lines, raw_pairs


def _parse_customer(conn, form):
    raw = field(form, "customer")
    if not raw:
        return None
    try:
        customer_id = int(raw)
    except ValueError:
        abort(400)
    customer = db_module.get_customer(conn, customer_id)
    if customer is None or customer["erased"]:
        abort(400)
    return customer_id


def _parse_jurisdiction(conn, form):
    code = field(form, "jurisdiction")
    jurisdiction = db_module.get_jurisdiction(conn, code) if code else None
    if jurisdiction is None:
        abort(400)
    return jurisdiction


def _parse_coupon_codes(conn, form):
    raw = form.get("coupon_codes") or ""
    codes = [chunk.strip() for chunk in raw.split(",") if chunk.strip()]
    known = {
        rule.code.strip()
        for rule in db_module.list_rules(conn)
        if rule.KIND == "coupon"
    }
    for code in codes:
        if code not in known:
            raise ValidationError(f"unknown coupon code: {code}", field="coupon_codes")
    return raw, codes


def _pad_rows(raw_pairs):
    rows = list(raw_pairs)
    while len(rows) < BLANK_ROWS:
        rows.append(("", ""))
    return rows


def _builder_context(conn, *, currency, jurisdiction_code, customer_id, coupon_codes_raw,
                      raw_pairs, message=None, error_field=None, priced_view=None,
                      no_lines=False):
    return {
        "jurisdictions": db_module.list_jurisdictions(conn),
        "customers": db_module.list_customers(conn),
        "products": db_module.list_products(conn),
        "currency": currency,
        "jurisdiction_code": jurisdiction_code,
        "customer_id": customer_id,
        "coupon_codes_raw": coupon_codes_raw,
        "rows": _pad_rows(raw_pairs),
        "message": message,
        "error_field": error_field,
        "priced": priced_view,
        "no_lines": no_lines,
    }


def _handle_builder_submit(conn, form):
    """Shared parsing for preview and save. Returns a dict describing the outcome.

    Raises werkzeug HTTPException (via abort) for the 400-class refusals.
    Raises ValidationError for the 200-class (re-render) refusals.
    """
    currency = field(form, "currency") or "EUR"
    jurisdiction = _parse_jurisdiction(conn, form)
    customer_id = _parse_customer(conn, form)
    coupon_codes_raw, coupon_codes = _parse_coupon_codes(conn, form)
    lines, raw_pairs = _parse_lines(conn, form)

    state = {
        "currency": currency,
        "jurisdiction": jurisdiction,
        "customer_id": customer_id,
        "coupon_codes_raw": coupon_codes_raw,
        "coupon_codes": coupon_codes,
        "raw_pairs": raw_pairs,
        "lines": lines,
    }
    return state


def register(app):
    @app.route("/invoices/new", methods=["GET"])
    def new_invoice():
        conn = get_conn()
        jurisdictions = db_module.list_jurisdictions(conn)
        default_jurisdiction = jurisdictions[0].code if jurisdictions else ""
        ctx = _builder_context(
            conn,
            currency="EUR",
            jurisdiction_code=default_jurisdiction,
            customer_id=None,
            coupon_codes_raw="",
            raw_pairs=[],
            no_lines=True,
        )
        return render_template("invoice_builder.html", **ctx)

    @app.route("/invoices/preview", methods=["POST"])
    def preview_invoice():
        conn = get_conn()
        form = request.form
        is_fragment = request.headers.get("HX-Request") == "true"

        try:
            state = _handle_builder_submit(conn, form)
        except ValidationError as exc:
            ctx = _builder_context(
                conn,
                currency=field(form, "currency") or "EUR",
                jurisdiction_code=field(form, "jurisdiction"),
                customer_id=field(form, "customer") or None,
                coupon_codes_raw=form.get("coupon_codes") or "",
                raw_pairs=list(zip_longest(form.getlist("sku"), form.getlist("quantity"), fillvalue="")),
                message=str(exc),
                error_field=exc.field,
            )
            template = "_builder_fragment.html" if is_fragment else "invoice_builder.html"
            return render_template(template, **ctx), 200

        if not state["lines"]:
            ctx = _builder_context(
                conn,
                currency=state["currency"],
                jurisdiction_code=state["jurisdiction"].code,
                customer_id=state["customer_id"],
                coupon_codes_raw=state["coupon_codes_raw"],
                raw_pairs=state["raw_pairs"],
                no_lines=True,
                message="Add at least one line to preview an invoice.",
            )
            template = "_builder_fragment.html" if is_fragment else "invoice_builder.html"
            return render_template(template, **ctx), 200

        invoice = Invoice(state["currency"], state["lines"], state["coupon_codes"])
        rules = db_module.list_rules(conn)
        try:
            priced = price(invoice, rules, state["jurisdiction"])
        except PricingError:
            abort(400)

        ctx = _builder_context(
            conn,
            currency=state["currency"],
            jurisdiction_code=state["jurisdiction"].code,
            customer_id=state["customer_id"],
            coupon_codes_raw=state["coupon_codes_raw"],
            raw_pairs=state["raw_pairs"],
            priced_view=view_from_priced(priced),
        )
        template = "_builder_fragment.html" if is_fragment else "invoice_builder.html"
        return render_template(template, **ctx), 200

    @app.route("/invoices", methods=["POST"])
    def create_invoice():
        conn = get_conn()
        form = request.form

        try:
            state = _handle_builder_submit(conn, form)
        except ValidationError as exc:
            ctx = _builder_context(
                conn,
                currency=field(form, "currency") or "EUR",
                jurisdiction_code=field(form, "jurisdiction"),
                customer_id=field(form, "customer") or None,
                coupon_codes_raw=form.get("coupon_codes") or "",
                raw_pairs=list(zip_longest(form.getlist("sku"), form.getlist("quantity"), fillvalue="")),
                message=str(exc),
                error_field=exc.field,
            )
            return render_template("invoice_builder.html", **ctx), 200

        if not state["lines"]:
            abort(400)

        invoice = Invoice(state["currency"], state["lines"], state["coupon_codes"])
        rules = db_module.list_rules(conn)
        try:
            priced = price(invoice, rules, state["jurisdiction"])
        except PricingError:
            abort(400)

        lines_payload = []
        for line in priced.lines:
            lines_payload.append(
                {
                    "sku": line.product.sku,
                    "name": line.product.name,
                    "quantity": line.quantity,
                    "unit_price": line.product.unit_price,
                    "gross": line.gross,
                    "line_discount": line.line_discount,
                    "net": line.net,
                    "invoice_discount": line.invoice_discount,
                    "taxable": line.taxable,
                    "tax": line.tax,
                    "total": line.total,
                    "applied": line.applied,
                }
            )

        from datetime import datetime, timezone

        invoice_id = db_module.add_invoice(
            conn,
            currency=priced.currency,
            jurisdiction_code=priced.jurisdiction.code,
            jurisdiction_name=priced.jurisdiction.name,
            customer_id=state["customer_id"],
            coupon_codes=state["coupon_codes"],
            applied=priced.applied,
            subtotal=priced.subtotal,
            discount_total=priced.discount_total,
            taxable_total=priced.taxable_total,
            tax_total=priced.tax_total,
            total=priced.total,
            lines=lines_payload,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        return redirect(url_for("invoice_detail", invoice_id=invoice_id))

    @app.route("/invoices/<int:invoice_id>", methods=["GET"])
    def invoice_detail(invoice_id):
        conn = get_conn()
        invoice_row = db_module.get_invoice(conn, invoice_id)
        if invoice_row is None:
            abort(404)
        customer = None
        if invoice_row["customer_id"] is not None:
            customer = db_module.get_customer(conn, invoice_row["customer_id"])
        view = view_from_stored(invoice_row)
        return render_template(
            "invoice_detail.html",
            invoice=invoice_row,
            view=view,
            customer=customer,
        )

    @app.route("/invoices/<int:invoice_id>/print", methods=["GET"])
    def invoice_print(invoice_id):
        conn = get_conn()
        invoice_row = db_module.get_invoice(conn, invoice_id)
        if invoice_row is None:
            abort(404)
        customer = None
        if invoice_row["customer_id"] is not None:
            customer = db_module.get_customer(conn, invoice_row["customer_id"])
        view = view_from_stored(invoice_row)
        return render_template(
            "invoice_print.html",
            invoice=invoice_row,
            view=view,
            customer=customer,
        )

    @app.route("/invoices/<int:invoice_id>/export.json", methods=["GET"])
    def invoice_export_json(invoice_id):
        conn = get_conn()
        invoice_row = db_module.get_invoice(conn, invoice_id)
        if invoice_row is None:
            abort(404)

        view = view_from_stored(invoice_row)
        payload = {"invoice_id": invoice_row["invoice_id"], **view}
        body = json.dumps(payload)
        return Response(body, mimetype="application/json")

    @app.route("/invoices/<int:invoice_id>/export.csv", methods=["GET"])
    def invoice_export_csv(invoice_id):
        conn = get_conn()
        invoice_row = db_module.get_invoice(conn, invoice_id)
        if invoice_row is None:
            abort(404)

        view = view_from_stored(invoice_row)

        buf = io.StringIO(newline="")
        writer = csv.writer(buf, lineterminator="\n")
        writer.writerow(
            [
                "sku", "name", "quantity", "unit_price", "gross", "line_discount",
                "net", "invoice_discount", "taxable", "tax", "total",
            ]
        )
        gross_sum = Decimal("0.00")
        discount_sum = Decimal("0.00")
        for line in view["lines"]:
            gross_sum += Decimal(line["gross"])
            discount_sum += Decimal(line["line_discount"])
            writer.writerow(
                [
                    line["sku"], line["name"], line["quantity"], line["unit_price"],
                    line["gross"], line["line_discount"], line["net"],
                    line["invoice_discount"], line["taxable"], line["tax"], line["total"],
                ]
            )
        writer.writerow(
            [
                "TOTAL", "", "", "",
                money(gross_sum),
                money(discount_sum),
                view["subtotal"],
                view["discount_total"],
                view["taxable_total"],
                view["tax_total"],
                view["total"],
            ]
        )
        body = buf.getvalue()
        return Response(body, content_type="text/csv; charset=utf-8")
