from flask import abort, redirect, render_template, request, url_for

from . import get_conn
from .. import db as db_module
from ..errors import ValidationError
from ..models import Jurisdiction
from .helpers import parse_decimal, parse_rates, require


def _render(conn, *, message=None, error_field=None, form=None, status=200):
    jurisdictions = db_module.list_jurisdictions(conn)
    return (
        render_template(
            "jurisdictions.html",
            jurisdictions=jurisdictions,
            message=message,
            error_field=error_field,
            form=form or {},
        ),
        status,
    )


def register(app):
    @app.route("/jurisdictions", methods=["GET"])
    def jurisdictions():
        conn = get_conn()
        return _render(conn)

    @app.route("/jurisdictions", methods=["POST"])
    def create_jurisdiction():
        conn = get_conn()
        form = request.form
        try:
            code = require(form, "code")
            if db_module.get_jurisdiction(conn, code) is not None:
                raise ValidationError("code already exists", field="code")
            name = require(form, "name")
            default_rate = parse_decimal(form, "default_rate")
            rates_raw = form.get("rates") or ""
            rates = parse_rates(rates_raw)
            jurisdiction = Jurisdiction(code, name, rates, default_rate)
        except ValidationError as exc:
            return _render(conn, message=str(exc), error_field=exc.field, form=form)

        db_module.add_jurisdiction(conn, jurisdiction)
        return redirect(url_for("jurisdictions"))

    @app.route("/jurisdictions/<code>/delete", methods=["POST"])
    def delete_jurisdiction(code):
        conn = get_conn()
        if db_module.get_jurisdiction(conn, code) is None:
            abort(404)
        db_module.delete_jurisdiction(conn, code)
        return redirect(url_for("jurisdictions"))
