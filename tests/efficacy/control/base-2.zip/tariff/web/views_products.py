from flask import abort, redirect, render_template, request, url_for

from . import get_conn
from .. import db as db_module
from ..errors import ValidationError
from ..models import Product
from .helpers import field, parse_decimal, require


def _render(conn, *, message=None, error_field=None, form=None, status=200):
    products = db_module.list_products(conn)
    return (
        render_template(
            "products.html",
            products=products,
            message=message,
            error_field=error_field,
            form=form or {},
        ),
        status,
    )


def register(app):
    @app.route("/products", methods=["GET"])
    def products():
        conn = get_conn()
        return _render(conn)

    @app.route("/products", methods=["POST"])
    def create_product():
        conn = get_conn()
        form = request.form
        try:
            sku = require(form, "sku")
            if db_module.get_product(conn, sku) is not None:
                raise ValidationError("sku already exists", field="sku")
            name = require(form, "name")
            unit_price = parse_decimal(form, "unit_price")
            tax_category = require(form, "tax_category")
            product = Product(sku, name, unit_price, tax_category)
        except ValidationError as exc:
            return _render(conn, message=str(exc), error_field=exc.field, form=form)

        db_module.add_product(conn, product)
        return redirect(url_for("products"))

    @app.route("/products/<sku>/delete", methods=["POST"])
    def delete_product(sku):
        conn = get_conn()
        if db_module.get_product(conn, sku) is None:
            abort(404)
        db_module.delete_product(conn, sku)
        return redirect(url_for("products"))
