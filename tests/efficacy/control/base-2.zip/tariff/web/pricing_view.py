"""Shared shaping of priced invoices (fresh or stored) for templates and exports."""

from decimal import Decimal

from .._decimal import round2
from .helpers import money


def view_from_priced(priced):
    """Shape a freshly computed :class:`tariff.PricedInvoice` for templates."""
    lines = []
    for line in priced.lines:
        lines.append(
            {
                "sku": line.product.sku,
                "name": line.product.name,
                "quantity": line.quantity,
                "unit_price": money(line.product.unit_price),
                "gross": money(round2(line.gross)),
                "line_discount": money(line.line_discount),
                "net": money(line.net),
                "invoice_discount": money(line.invoice_discount),
                "taxable": money(line.taxable),
                "tax": money(line.tax),
                "total": money(line.total),
                "applied": line.applied,
            }
        )
    return {
        "currency": priced.currency,
        "jurisdiction": priced.jurisdiction.code,
        "lines": lines,
        "subtotal": money(priced.subtotal),
        "discount_total": money(priced.discount_total),
        "taxable_total": money(priced.taxable_total),
        "tax_total": money(priced.tax_total),
        "total": money(priced.total),
        "applied": priced.applied,
    }


def view_from_stored(invoice_row):
    """Shape a database row (as returned by ``db.get_invoice``) for templates."""
    lines = []
    for line in invoice_row["lines"]:
        lines.append(
            {
                "sku": line["sku"],
                "name": line["name"],
                "quantity": line["quantity"],
                "unit_price": money(Decimal(line["unit_price"])),
                "gross": money(round2(Decimal(line["gross"]))),
                "line_discount": money(Decimal(line["line_discount"])),
                "net": money(Decimal(line["net"])),
                "invoice_discount": money(Decimal(line["invoice_discount"])),
                "taxable": money(Decimal(line["taxable"])),
                "tax": money(Decimal(line["tax"])),
                "total": money(Decimal(line["total"])),
                "applied": line["applied"],
            }
        )
    return {
        "currency": invoice_row["currency"],
        "jurisdiction": invoice_row["jurisdiction_code"],
        "lines": lines,
        "subtotal": money(Decimal(invoice_row["subtotal"])),
        "discount_total": money(Decimal(invoice_row["discount_total"])),
        "taxable_total": money(Decimal(invoice_row["taxable_total"])),
        "tax_total": money(Decimal(invoice_row["tax_total"])),
        "total": money(Decimal(invoice_row["total"])),
        "applied": invoice_row["applied"],
    }
