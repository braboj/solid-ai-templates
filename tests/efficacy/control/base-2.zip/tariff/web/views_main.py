from flask import render_template


def register(app):
    @app.route("/")
    def dashboard():
        return render_template("dashboard.html")
