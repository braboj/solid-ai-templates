"""Shared decimal helpers. Floats never enter the pricing path."""

from decimal import Decimal, ROUND_DOWN, ROUND_HALF_EVEN

from .errors import ValidationError

TWO_PLACES = Decimal("0.01")


def to_decimal(value, *, field=None):
    """Coerce ``value`` to a Decimal, refusing floats outright."""
    if isinstance(value, float):
        raise ValidationError(f"{field or 'value'} must not be a float", field=field)
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def round2(value):
    """Round half-even to two decimal places."""
    return value.quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)


def truncate2(value):
    """Truncate (toward zero) to two decimal places."""
    return value.quantize(TWO_PLACES, rounding=ROUND_DOWN)
