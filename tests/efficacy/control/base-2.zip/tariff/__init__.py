"""tariff: a pricing and invoicing engine, plus an optional web UI.

``import tariff`` never touches Flask or the database; only
``tariff.create_app`` does, and only once it is called.
"""

from .errors import PricingError, TariffError, UnknownSkuError, ValidationError
from .models import Catalog, Invoice, InvoiceLine, Jurisdiction, Product
from .pricing import PricedInvoice, PricedLine, price
from .rules import BulkRule, CouponRule, PercentageRule, TieredRule

__all__ = [
    "Product",
    "Catalog",
    "InvoiceLine",
    "Invoice",
    "Jurisdiction",
    "PercentageRule",
    "BulkRule",
    "TieredRule",
    "CouponRule",
    "price",
    "PricedInvoice",
    "PricedLine",
    "TariffError",
    "ValidationError",
    "UnknownSkuError",
    "PricingError",
    "create_app",
]


def create_app(db_path):
    """Build and return the Flask application. Imports Flask lazily."""
    from .web import create_app as _create_app

    return _create_app(db_path)
