"""The pricing algorithm fixed by SPEC.md section 4."""

from dataclasses import dataclass, field
from decimal import Decimal, localcontext
from typing import List, Optional

from ._decimal import round2, truncate2
from .errors import PricingError
from .rules import BulkRule, CouponRule, PercentageRule, TieredRule


@dataclass
class PricedLine:
    product: object
    quantity: int
    gross: Decimal
    line_discount: Decimal
    net: Decimal
    invoice_discount: Optional[Decimal]
    taxable: Optional[Decimal]
    tax: Optional[Decimal]
    total: Optional[Decimal]
    applied: List[str]


@dataclass
class PricedInvoice:
    currency: str
    jurisdiction: object
    lines: List[PricedLine]
    subtotal: Decimal
    discount_total: Decimal
    taxable_total: Decimal
    tax_total: Decimal
    total: Decimal
    applied: List[str]


def _select_best(candidates, compute_fn):
    """Pick the candidate producing the lowest amount, ties by rule_id."""
    if not candidates:
        return None, None
    scored = [(compute_fn(rule), rule) for rule in candidates]
    scored.sort(key=lambda pair: (pair[0], pair[1].rule_id))
    return scored[0]


def _tiered_amount(rule, quantity, running):
    applicable_price = None
    for min_quantity, unit_price in rule.tiers:
        if quantity >= min_quantity:
            applicable_price = unit_price
        else:
            break
    if applicable_price is None:
        return running
    return applicable_price * quantity


def _bulk_amount(rule, quantity, running):
    groups, remainder = divmod(quantity, rule.buy)
    chargeable_units = groups * rule.pay + remainder
    return running / quantity * chargeable_units


def _percentage_amount(rule, running):
    return running * (1 - rule.percent / Decimal(100))


def _coupon_amount(rule, running):
    if rule.percent is not None:
        return _percentage_amount(rule, running)
    return running - min(rule.amount, running)


def _price_line(line, rules):
    product = line.product
    quantity = line.quantity
    gross = product.unit_price * quantity
    running = gross
    applied = []

    tiered_candidates = [
        r for r in rules if isinstance(r, TieredRule) and r.sku == product.sku
    ]
    amount, rule = _select_best(
        tiered_candidates, lambda r: _tiered_amount(r, quantity, running)
    )
    if rule is not None:
        running = amount
        applied.append(rule.rule_id)

    bulk_candidates = [
        r for r in rules if isinstance(r, BulkRule) and r.sku == product.sku
    ]
    amount, rule = _select_best(
        bulk_candidates, lambda r: _bulk_amount(r, quantity, running)
    )
    if rule is not None:
        running = amount
        applied.append(rule.rule_id)

    pct_candidates = [
        r
        for r in rules
        if isinstance(r, PercentageRule) and r.sku == product.sku
    ]
    amount, rule = _select_best(
        pct_candidates, lambda r: _percentage_amount(r, running)
    )
    if rule is not None:
        running = amount
        applied.append(rule.rule_id)

    net = round2(running)
    line_discount = round2(gross) - net
    return PricedLine(
        product=product,
        quantity=quantity,
        gross=gross,
        line_discount=line_discount,
        net=net,
        invoice_discount=None,
        taxable=None,
        tax=None,
        total=None,
        applied=applied,
    )


def _apply_invoice_rules(subtotal, rules, stripped_codes):
    running = subtotal
    applied = []

    pct_candidates = [
        r for r in rules if isinstance(r, PercentageRule) and r.sku is None
    ]
    amount, rule = _select_best(
        pct_candidates, lambda r: round2(_percentage_amount(r, running))
    )
    if rule is not None:
        running = amount
        applied.append(rule.rule_id)

    coupon_candidates = [
        r
        for r in rules
        if isinstance(r, CouponRule) and r.code.strip() in stripped_codes
    ]
    amount, rule = _select_best(
        coupon_candidates, lambda r: round2(_coupon_amount(r, running))
    )
    if rule is not None:
        running = amount
        applied.append(rule.rule_id)

    return running, applied


def _allocate(discount_total, nets, subtotal):
    count = len(nets)
    if subtotal == 0:
        return [Decimal("0.00")] * count

    exact_shares = [discount_total * net / subtotal for net in nets]
    truncated = [truncate2(share) for share in exact_shares]

    target_cents = int((discount_total * 100).to_integral_value())
    truncated_cents = [int((t * 100).to_integral_value()) for t in truncated]
    remaining_cents = target_cents - sum(truncated_cents)

    fractions = [exact_shares[i] - truncated[i] for i in range(count)]
    order = sorted(range(count), key=lambda i: (-fractions[i], i))

    alloc_cents = truncated_cents[:]
    for i in order[:remaining_cents]:
        alloc_cents[i] += 1

    return [(Decimal(c) / 100).quantize(Decimal("0.01")) for c in alloc_cents]


def price(invoice, rules, jurisdiction):
    """Price ``invoice`` against ``rules`` in ``jurisdiction``."""
    if not invoice.lines:
        raise PricingError("invoice has no lines")
    for line in invoice.lines:
        if line.quantity < 1:
            raise PricingError("line quantity must be at least one")

    rule_ids = [r.rule_id for r in rules]
    if len(rule_ids) != len(set(rule_ids)):
        raise PricingError("duplicate rule_id among rules")

    coupon_rules = [r for r in rules if isinstance(r, CouponRule)]
    known_codes = {r.code.strip() for r in coupon_rules}
    stripped_codes = [code.strip() for code in invoice.coupon_codes]
    for code in stripped_codes:
        if code not in known_codes:
            raise PricingError(f"unknown coupon code: {code}")

    with localcontext() as ctx:
        ctx.prec = 50

        priced_lines = [_price_line(line, rules) for line in invoice.lines]

        subtotal = sum((pl.net for pl in priced_lines), Decimal("0.00"))

        discounted_subtotal, applied_invoice = _apply_invoice_rules(
            subtotal, rules, stripped_codes
        )
        discount_total = subtotal - discounted_subtotal

        allocations = _allocate(
            discount_total, [pl.net for pl in priced_lines], subtotal
        )

        tax_total = Decimal("0.00")
        for priced_line, allocation in zip(priced_lines, allocations):
            taxable = priced_line.net - allocation
            rate = jurisdiction.rates.get(
                priced_line.product.tax_category, jurisdiction.default_rate
            )
            tax = round2(taxable * rate)
            priced_line.invoice_discount = allocation
            priced_line.taxable = taxable
            priced_line.tax = tax
            priced_line.total = taxable + tax
            tax_total += tax

        taxable_total = discounted_subtotal
        total = discounted_subtotal + tax_total

        return PricedInvoice(
            currency=invoice.currency,
            jurisdiction=jurisdiction,
            lines=priced_lines,
            subtotal=subtotal,
            discount_total=discount_total,
            taxable_total=taxable_total,
            tax_total=tax_total,
            total=total,
            applied=applied_invoice,
        )
